package com.example.domain

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AcUnit
import androidx.compose.material.icons.filled.Cloud
import androidx.compose.material.icons.filled.CloudQueue
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.FilterDrama
import androidx.compose.material.icons.filled.Grain
import androidx.compose.material.icons.filled.Thunderstorm
import androidx.compose.material.icons.filled.WaterDrop
import androidx.compose.material.icons.filled.WbSunny
import androidx.compose.material.icons.filled.WbTwilight
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import com.example.data.local.MonitoredLocationEntity
import com.example.data.local.TimeWatchRuleEntity
import java.util.Locale
import kotlin.math.roundToInt

data class HourlyWeatherPoint(
    val index: Int,
    val isoTime: String,           // e.g. "2026-09-28T14:00"
    val dayKey: String,            // e.g. "2026-09-28"
    val hourOfDay: Int,            // 0..23
    val displayTime12h: String,    // e.g. "2:00 PM"
    val displayTime24h: String,    // e.g. "14:00"
    val displayDayLabel: String,   // e.g. "Today", "Tomorrow", "Wed, Sep 30"
    val tempC: Double,
    val feelsLikeC: Double,
    val humidity: Int,
    val dewPointC: Double,
    val precipProb: Int,
    val precipMm: Double,
    val weatherCode: Int,
    val pressureHpa: Double,
    val cloudCover: Int,
    val visibilityKm: Double,
    val windSpeedKmh: Double,
    val windDirectionDeg: Int,
    val windGustsKmh: Double,
    val uvIndex: Double,
    val isDay: Boolean,
    val isCurrentHour: Boolean,
    val hoursOffsetFromNow: Int
)

data class DailyWeatherSummary(
    val dateIso: String,
    val displayDayName: String,
    val displayShortDate: String,
    val weatherCode: Int,
    val maxTempC: Double,
    val minTempC: Double,
    val sunriseIso: String,
    val sunsetIso: String,
    val sunriseFormatted: String,
    val sunsetFormatted: String,
    val sunriseHourFloat: Float,
    val sunsetHourFloat: Float,
    val uvMax: Double,
    val precipProbMax: Int,
    val precipSumMm: Double,
    val maxWindKmh: Double,
    val firstHourIndex: Int
)

data class LocationWeatherBundle(
    val location: MonitoredLocationEntity,
    val timezoneId: String,
    val timezoneAbbrev: String,
    val utcOffsetSeconds: Int,
    val elevationMeters: Double,
    val currentLocalTimeFormatted: String,
    val currentLocalDateFormatted: String,
    val currentHourIndex: Int,
    val hourlyPoints: List<HourlyWeatherPoint>,
    val dailySummaries: List<DailyWeatherSummary>,
    val fetchedAtMillis: Long,
    val isFromLiveNetwork: Boolean = true
)

data class TimeWatchEvaluation(
    val rule: TimeWatchRuleEntity,
    val targetHourFormatted: String,
    val matchedPoint: HourlyWeatherPoint?,
    val isTriggered: Boolean,
    val triggerReasons: List<String>,
    val statusSummary: String
)

data class WmoWeatherInfo(
    val code: Int,
    val title: String,
    val subtitle: String,
    val icon: ImageVector,
    val accentColor: Color
)

object WeatherFormatter {

    fun formatTemp(tempC: Double, useFahrenheit: Boolean): String {
        val value = if (useFahrenheit) (tempC * 9.0 / 5.0) + 32.0 else tempC
        return "${value.roundToInt()}°"
    }

    fun formatTempWithUnit(tempC: Double, useFahrenheit: Boolean): String {
        val value = if (useFahrenheit) (tempC * 9.0 / 5.0) + 32.0 else tempC
        val unit = if (useFahrenheit) "F" else "C"
        return "${value.roundToInt()}°$unit"
    }

    fun formatWindSpeed(kmh: Double, useImperial: Boolean): String {
        return if (useImperial) {
            val mph = kmh * 0.621371
            String.format(Locale.US, "%.1f mph", mph)
        } else {
            String.format(Locale.US, "%.1f km/h", kmh)
        }
    }

    fun degreeToCardinal(deg: Int): String {
        val directions = arrayOf(
            "N", "NNE", "NE", "ENE",
            "E", "ESE", "SE", "SSE",
            "S", "SSW", "SW", "WSW",
            "W", "WNW", "NW", "NNW"
        )
        val normalized = ((deg % 360) + 360) % 360
        val idx = ((normalized / 22.5) + 0.5).toInt() % 16
        return directions[idx]
    }

    fun uvCategory(uv: Double): String = when {
        uv < 3.0 -> "Low"
        uv < 6.0 -> "Moderate"
        uv < 8.0 -> "High"
        uv < 11.0 -> "Very High"
        else -> "Extreme"
    }

    fun formatHourLabel24(hour: Int): String {
        val h = hour.coerceIn(0, 23)
        return String.format(Locale.US, "%02d:00", h)
    }

    fun formatHourLabel12(hour: Int): String {
        val h = hour.coerceIn(0, 23)
        val amPm = if (h < 12) "AM" else "PM"
        val h12 = when {
            h == 0 -> 12
            h > 12 -> h - 12
            else -> h
        }
        return "$h12:00 $amPm"
    }

    fun formatOffsetBadge(offsetHours: Int): String = when {
        offsetHours == 0 -> "LIVE NOW"
        offsetHours > 0 -> "+${offsetHours}h AHEAD"
        else -> "${offsetHours}h PAST"
    }

    fun resolveWmoCode(code: Int, isDay: Boolean): WmoWeatherInfo {
        return when (code) {
            0 -> WmoWeatherInfo(
                code = code,
                title = if (isDay) "Clear Sky" else "Starlit Clear",
                subtitle = if (isDay) "Unobstructed solar radiation and high visibility" else "Clear nocturnal sky with radiative cooling",
                icon = if (isDay) Icons.Filled.WbSunny else Icons.Filled.DarkMode,
                accentColor = if (isDay) Color(0xFFFBBF24) else Color(0xFF818CF8)
            )
            1 -> WmoWeatherInfo(
                code = code,
                title = if (isDay) "Mainly Clear" else "Mostly Clear Night",
                subtitle = "Scattered high-altitude cirrus wisps",
                icon = if (isDay) Icons.Filled.WbSunny else Icons.Filled.DarkMode,
                accentColor = if (isDay) Color(0xFFFBBF24) else Color(0xFF93C5FD)
            )
            2 -> WmoWeatherInfo(
                code = code,
                title = "Partly Cloudy",
                subtitle = "Partial cumulus cloud deck with filtered light",
                icon = Icons.Filled.FilterDrama,
                accentColor = Color(0xFF38BDF8)
            )
            3 -> WmoWeatherInfo(
                code = code,
                title = "Overcast",
                subtitle = "Uniform stratus cloud canopy across the horizon",
                icon = Icons.Filled.Cloud,
                accentColor = Color(0xFF94A3B8)
            )
            45, 48 -> WmoWeatherInfo(
                code = code,
                title = "Atmospheric Fog",
                subtitle = "Reduced horizontal visibility due to suspended mist",
                icon = Icons.Filled.WbTwilight,
                accentColor = Color(0xFFCBD5E1)
            )
            51, 53, 55, 56, 57 -> WmoWeatherInfo(
                code = code,
                title = "Light Drizzle",
                subtitle = "Fine moisture droplets descending from low stratus",
                icon = Icons.Filled.Grain,
                accentColor = Color(0xFF60A5FA)
            )
            61, 63, 65, 66, 67 -> WmoWeatherInfo(
                code = code,
                title = if (code >= 65) "Heavy Rain" else "Steady Rain",
                subtitle = "Active frontal precipitation across the sector",
                icon = Icons.Filled.WaterDrop,
                accentColor = Color(0xFF38BDF8)
            )
            71, 73, 75, 77, 85, 86 -> WmoWeatherInfo(
                code = code,
                title = "Snowfall",
                subtitle = "Crystalline frozen precipitation and sub-zero airmass",
                icon = Icons.Filled.AcUnit,
                accentColor = Color(0xFFE0F2FE)
            )
            80, 81, 82 -> WmoWeatherInfo(
                code = code,
                title = "Rain Showers",
                subtitle = "Convective passing rain bands with gusty shifts",
                icon = Icons.Filled.WaterDrop,
                accentColor = Color(0xFF0EA5E9)
            )
            95, 96, 99 -> WmoWeatherInfo(
                code = code,
                title = "Thunderstorm",
                subtitle = "Deep convective storm cell with electrical activity",
                icon = Icons.Filled.Thunderstorm,
                accentColor = Color(0xFFFB7185)
            )
            else -> WmoWeatherInfo(
                code = code,
                title = "Variable Clouds",
                subtitle = "Shifting atmospheric conditions",
                icon = Icons.Filled.CloudQueue,
                accentColor = Color(0xFF38BDF8)
            )
        }
    }
}
