package com.example.data.remote

import com.squareup.moshi.Json

data class OpenMeteoForecastResponse(
    @Json(name = "latitude") val latitude: Double = 0.0,
    @Json(name = "longitude") val longitude: Double = 0.0,
    @Json(name = "elevation") val elevation: Double? = 0.0,
    @Json(name = "timezone") val timezone: String? = "UTC",
    @Json(name = "timezone_abbreviation") val timezoneAbbreviation: String? = "UTC",
    @Json(name = "utc_offset_seconds") val utcOffsetSeconds: Int? = 0,
    @Json(name = "current") val current: CurrentWeatherDto? = null,
    @Json(name = "hourly") val hourly: HourlyWeatherDto? = null,
    @Json(name = "daily") val daily: DailyWeatherDto? = null
)

data class CurrentWeatherDto(
    @Json(name = "time") val time: String? = null,
    @Json(name = "temperature_2m") val temperature2m: Double? = null,
    @Json(name = "relative_humidity_2m") val relativeHumidity2m: Int? = null,
    @Json(name = "apparent_temperature") val apparentTemperature: Double? = null,
    @Json(name = "is_day") val isDay: Int? = 1,
    @Json(name = "precipitation") val precipitation: Double? = 0.0,
    @Json(name = "weather_code") val weatherCode: Int? = 0,
    @Json(name = "cloud_cover") val cloudCover: Int? = 0,
    @Json(name = "surface_pressure") val surfacePressure: Double? = 1013.25,
    @Json(name = "wind_speed_10m") val windSpeed10m: Double? = 0.0,
    @Json(name = "wind_direction_10m") val windDirection10m: Int? = 0,
    @Json(name = "wind_gusts_10m") val windGusts10m: Double? = 0.0
)

data class HourlyWeatherDto(
    @Json(name = "time") val time: List<String> = emptyList(),
    @Json(name = "temperature_2m") val temperature2m: List<Double?> = emptyList(),
    @Json(name = "relative_humidity_2m") val relativeHumidity2m: List<Int?> = emptyList(),
    @Json(name = "dew_point_2m") val dewPoint2m: List<Double?> = emptyList(),
    @Json(name = "apparent_temperature") val apparentTemperature: List<Double?> = emptyList(),
    @Json(name = "precipitation_probability") val precipitationProbability: List<Int?> = emptyList(),
    @Json(name = "precipitation") val precipitation: List<Double?> = emptyList(),
    @Json(name = "weather_code") val weatherCode: List<Int?> = emptyList(),
    @Json(name = "surface_pressure") val surfacePressure: List<Double?> = emptyList(),
    @Json(name = "cloud_cover") val cloudCover: List<Int?> = emptyList(),
    @Json(name = "visibility") val visibility: List<Double?> = emptyList(),
    @Json(name = "wind_speed_10m") val windSpeed10m: List<Double?> = emptyList(),
    @Json(name = "wind_direction_10m") val windDirection10m: List<Int?> = emptyList(),
    @Json(name = "wind_gusts_10m") val windGusts10m: List<Double?> = emptyList(),
    @Json(name = "uv_index") val uvIndex: List<Double?> = emptyList(),
    @Json(name = "is_day") val isDay: List<Int?> = emptyList()
)

data class DailyWeatherDto(
    @Json(name = "time") val time: List<String> = emptyList(),
    @Json(name = "weather_code") val weatherCode: List<Int?> = emptyList(),
    @Json(name = "temperature_2m_max") val temperature2mMax: List<Double?> = emptyList(),
    @Json(name = "temperature_2m_min") val temperature2mMin: List<Double?> = emptyList(),
    @Json(name = "sunrise") val sunrise: List<String?> = emptyList(),
    @Json(name = "sunset") val sunset: List<String?> = emptyList(),
    @Json(name = "uv_index_max") val uvIndexMax: List<Double?> = emptyList(),
    @Json(name = "precipitation_sum") val precipitationSum: List<Double?> = emptyList(),
    @Json(name = "precipitation_probability_max") val precipitationProbabilityMax: List<Int?> = emptyList(),
    @Json(name = "wind_speed_10m_max") val windSpeed10mMax: List<Double?> = emptyList()
)

data class GeocodingSearchResponse(
    @Json(name = "results") val results: List<GeocodingResultDto>? = emptyList()
)

data class GeocodingResultDto(
    @Json(name = "id") val id: Long = 0,
    @Json(name = "name") val name: String = "",
    @Json(name = "latitude") val latitude: Double = 0.0,
    @Json(name = "longitude") val longitude: Double = 0.0,
    @Json(name = "elevation") val elevation: Double? = null,
    @Json(name = "country") val country: String? = null,
    @Json(name = "admin1") val admin1: String? = null,
    @Json(name = "timezone") val timezone: String? = "UTC"
)
