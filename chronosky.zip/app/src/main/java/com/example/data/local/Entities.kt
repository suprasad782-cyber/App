package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "monitored_locations")
data class MonitoredLocationEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val region: String,
    val country: String,
    val latitude: Double,
    val longitude: Double,
    val timezone: String = "UTC",
    val isGpsLocation: Boolean = false,
    val isPrimary: Boolean = false,
    val lastTempC: Double? = null,
    val lastWeatherCode: Int? = null,
    val lastWindKmh: Double? = null,
    val lastHumidity: Int? = null,
    val lastIsDay: Boolean = true,
    val lastUpdatedMillis: Long = 0L
)

@Entity(tableName = "weather_logs")
data class WeatherLogEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val locationName: String,
    val regionCountry: String,
    val latitude: Double,
    val longitude: Double,
    val timezone: String,
    val targetTimeIso: String,
    val targetTimeFormatted: String,
    val recordedAtMillis: Long = System.currentTimeMillis(),
    val temperatureC: Double,
    val apparentTempC: Double,
    val weatherCode: Int,
    val weatherCondition: String,
    val precipitationProb: Int,
    val windSpeedKmh: Double,
    val windDirectionDeg: Int,
    val humidity: Int,
    val pressureHpa: Double,
    val uvIndex: Double,
    val isDay: Boolean,
    val note: String = ""
)

@Entity(tableName = "time_watch_rules")
data class TimeWatchRuleEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val label: String,
    val locationId: Long,
    val locationName: String,
    val latitude: Double,
    val longitude: Double,
    val timezone: String,
    val targetHour: Int, // 0..23 in location's local time
    val maxRainProbPercent: Int = 40,
    val maxWindKmh: Double = 30.0,
    val minTempC: Double = 5.0,
    val maxTempC: Double = 35.0,
    val isEnabled: Boolean = true,
    val createdAtMillis: Long = System.currentTimeMillis()
)
