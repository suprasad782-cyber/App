package com.example.data.repository

import com.example.data.local.MonitoredLocationEntity
import com.example.data.local.TimeWatchRuleEntity
import com.example.data.local.WeatherDao
import com.example.data.local.WeatherLogEntity
import com.example.data.remote.GeocodingResultDto
import com.example.data.remote.OpenMeteoForecastResponse
import com.example.data.remote.OpenMeteoForecastService
import com.example.data.remote.OpenMeteoGeocodingService
import com.example.data.remote.OpenMeteoNetwork
import com.example.domain.DailyWeatherSummary
import com.example.domain.HourlyWeatherPoint
import com.example.domain.LocationWeatherBundle
import com.example.domain.TimeWatchEvaluation
import com.example.domain.WeatherFormatter
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import kotlin.math.cos
import kotlin.math.roundToInt
import kotlin.math.sin

class WeatherRepository(
    private val weatherDao: WeatherDao,
    private val forecastService: OpenMeteoForecastService = OpenMeteoNetwork.forecastService,
    private val geocodingService: OpenMeteoGeocodingService = OpenMeteoNetwork.geocodingService
) {
    val allLocations: Flow<List<MonitoredLocationEntity>> = weatherDao.getAllLocations()
    val allWeatherLogs: Flow<List<WeatherLogEntity>> = weatherDao.getAllWeatherLogs()
    val allTimeWatchRules: Flow<List<TimeWatchRuleEntity>> = weatherDao.getAllTimeWatchRules()

    private val bundleMemoryCache = mutableMapOf<Long, LocationWeatherBundle>()

    suspend fun ensureSeededLocations(): List<MonitoredLocationEntity> = withContext(Dispatchers.IO) {
        val existing = weatherDao.getAllLocationsOnce()
        if (existing.isNotEmpty()) {
            return@withContext existing
        }

        val initialStations = listOf(
            MonitoredLocationEntity(
                name = "San Francisco",
                region = "California",
                country = "United States",
                latitude = 37.7749,
                longitude = -122.4194,
                timezone = "America/Los_Angeles",
                isGpsLocation = false,
                isPrimary = true
            ),
            MonitoredLocationEntity(
                name = "New York",
                region = "New York",
                country = "United States",
                latitude = 40.7128,
                longitude = -74.0060,
                timezone = "America/New_York",
                isGpsLocation = false,
                isPrimary = false
            ),
            MonitoredLocationEntity(
                name = "London",
                region = "England",
                country = "United Kingdom",
                latitude = 51.5074,
                longitude = -0.1278,
                timezone = "Europe/London",
                isGpsLocation = false,
                isPrimary = false
            ),
            MonitoredLocationEntity(
                name = "Tokyo",
                region = "Kanto",
                country = "Japan",
                latitude = 35.6762,
                longitude = 139.6503,
                timezone = "Asia/Tokyo",
                isGpsLocation = false,
                isPrimary = false
            ),
            MonitoredLocationEntity(
                name = "Bengaluru",
                region = "Karnataka",
                country = "India",
                latitude = 12.9716,
                longitude = 77.5946,
                timezone = "Asia/Kolkata",
                isGpsLocation = false,
                isPrimary = false
            )
        )

        val insertedIds = initialStations.map { weatherDao.insertLocation(it) }
        val primaryId = insertedIds.firstOrNull() ?: 1L

        val existingWatches = weatherDao.getAllTimeWatchRulesOnce()
        if (existingWatches.isEmpty()) {
            weatherDao.insertTimeWatchRule(
                TimeWatchRuleEntity(
                    label = "Morning Commute Window",
                    locationId = primaryId,
                    locationName = "San Francisco",
                    latitude = 37.7749,
                    longitude = -122.4194,
                    timezone = "America/Los_Angeles",
                    targetHour = 8,
                    maxRainProbPercent = 30,
                    maxWindKmh = 28.0,
                    minTempC = 8.0,
                    maxTempC = 30.0
                )
            )
            weatherDao.insertTimeWatchRule(
                TimeWatchRuleEntity(
                    label = "Evening Run & Sunset Check",
                    locationId = primaryId,
                    locationName = "San Francisco",
                    latitude = 37.7749,
                    longitude = -122.4194,
                    timezone = "America/Los_Angeles",
                    targetHour = 18,
                    maxRainProbPercent = 25,
                    maxWindKmh = 24.0,
                    minTempC = 10.0,
                    maxTempC = 28.0
                )
            )
        }

        weatherDao.getAllLocationsOnce()
    }

    suspend fun upsertGpsLocation(resolved: ResolvedGpsLocation): MonitoredLocationEntity =
        withContext(Dispatchers.IO) {
            val currentGps = weatherDao.getGpsLocation()
            val locationId = if (currentGps != null) {
                val updated = currentGps.copy(
                    name = resolved.cityName,
                    region = resolved.regionName,
                    country = resolved.countryName,
                    latitude = resolved.latitude,
                    longitude = resolved.longitude,
                    timezone = resolved.timezoneId,
                    isGpsLocation = true,
                    isPrimary = true
                )
                weatherDao.updateLocation(updated)
                currentGps.id
            } else {
                val newGps = MonitoredLocationEntity(
                    name = resolved.cityName,
                    region = resolved.regionName,
                    country = resolved.countryName,
                    latitude = resolved.latitude,
                    longitude = resolved.longitude,
                    timezone = resolved.timezoneId,
                    isGpsLocation = true,
                    isPrimary = true
                )
                weatherDao.insertLocation(newGps)
            }
            weatherDao.setPrimaryLocation(locationId)
            weatherDao.getLocationById(locationId)
                ?: MonitoredLocationEntity(
                    id = locationId,
                    name = resolved.cityName,
                    region = resolved.regionName,
                    country = resolved.countryName,
                    latitude = resolved.latitude,
                    longitude = resolved.longitude,
                    timezone = resolved.timezoneId,
                    isGpsLocation = true,
                    isPrimary = true
                )
        }

    suspend fun searchLocationsRemote(query: String): Result<List<GeocodingResultDto>> =
        withContext(Dispatchers.IO) {
            val trimmed = query.trim()
            if (trimmed.length < 2) {
                return@withContext Result.success(emptyList())
            }
            try {
                val response = geocodingService.searchLocations(query = trimmed, count = 10)
                Result.success(response.results.orEmpty())
            } catch (e: Exception) {
                Result.failure(e)
            }
        }

    suspend fun addLocationFromSearch(dto: GeocodingResultDto, makePrimary: Boolean = true): MonitoredLocationEntity =
        withContext(Dispatchers.IO) {
            val entity = MonitoredLocationEntity(
                name = dto.name,
                region = dto.admin1 ?: "Sector",
                country = dto.country ?: "Global",
                latitude = dto.latitude,
                longitude = dto.longitude,
                timezone = dto.timezone ?: "UTC",
                isGpsLocation = false,
                isPrimary = makePrimary
            )
            val id = weatherDao.insertLocation(entity)
            if (makePrimary) {
                weatherDao.setPrimaryLocation(id)
            }
            weatherDao.getLocationById(id) ?: entity.copy(id = id)
        }

    suspend fun selectPrimaryLocation(locationId: Long) = withContext(Dispatchers.IO) {
        weatherDao.setPrimaryLocation(locationId)
    }

    suspend fun deleteLocation(locationId: Long) = withContext(Dispatchers.IO) {
        weatherDao.deleteLocationById(locationId)
        bundleMemoryCache.remove(locationId)
    }

    suspend fun logWeatherSnapshot(
        location: MonitoredLocationEntity,
        point: HourlyWeatherPoint,
        note: String
    ): Long = withContext(Dispatchers.IO) {
        val wmo = WeatherFormatter.resolveWmoCode(point.weatherCode, point.isDay)
        val log = WeatherLogEntity(
            locationName = location.name,
            regionCountry = "${location.region}, ${location.country}",
            latitude = location.latitude,
            longitude = location.longitude,
            timezone = location.timezone,
            targetTimeIso = point.isoTime,
            targetTimeFormatted = "${point.displayDayLabel} • ${point.displayTime24h} (${point.displayTime12h})",
            recordedAtMillis = System.currentTimeMillis(),
            temperatureC = point.tempC,
            apparentTempC = point.feelsLikeC,
            weatherCode = point.weatherCode,
            weatherCondition = wmo.title,
            precipitationProb = point.precipProb,
            windSpeedKmh = point.windSpeedKmh,
            windDirectionDeg = point.windDirectionDeg,
            humidity = point.humidity,
            pressureHpa = point.pressureHpa,
            uvIndex = point.uvIndex,
            isDay = point.isDay,
            note = note.trim()
        )
        weatherDao.insertWeatherLog(log)
    }

    suspend fun deleteWeatherLog(logId: Long) = withContext(Dispatchers.IO) {
        weatherDao.deleteWeatherLogById(logId)
    }

    suspend fun clearAllWeatherLogs() = withContext(Dispatchers.IO) {
        weatherDao.clearAllWeatherLogs()
    }

    suspend fun addTimeWatchRule(
        label: String,
        location: MonitoredLocationEntity,
        targetHour: Int,
        maxRainProbPercent: Int,
        maxWindKmh: Double,
        minTempC: Double,
        maxTempC: Double
    ): Long = withContext(Dispatchers.IO) {
        val rule = TimeWatchRuleEntity(
            label = label.ifBlank { "${location.name} ${WeatherFormatter.formatHourLabel24(targetHour)} Watch" },
            locationId = location.id,
            locationName = location.name,
            latitude = location.latitude,
            longitude = location.longitude,
            timezone = location.timezone,
            targetHour = targetHour.coerceIn(0, 23),
            maxRainProbPercent = maxRainProbPercent.coerceIn(0, 100),
            maxWindKmh = maxWindKmh,
            minTempC = minTempC,
            maxTempC = maxTempC,
            isEnabled = true
        )
        weatherDao.insertTimeWatchRule(rule)
    }

    suspend fun toggleTimeWatchRule(rule: TimeWatchRuleEntity) = withContext(Dispatchers.IO) {
        weatherDao.updateTimeWatchRule(rule.copy(isEnabled = !rule.isEnabled))
    }

    suspend fun deleteTimeWatchRule(ruleId: Long) = withContext(Dispatchers.IO) {
        weatherDao.deleteTimeWatchRuleById(ruleId)
    }

    suspend fun fetchWeatherForLocation(
        location: MonitoredLocationEntity,
        forceRefresh: Boolean = false
    ): LocationWeatherBundle = withContext(Dispatchers.IO) {
        val cached = bundleMemoryCache[location.id]
        if (!forceRefresh && cached != null && (System.currentTimeMillis() - cached.fetchedAtMillis) < 5 * 60 * 1000L) {
            return@withContext cached
        }

        try {
            val response = forecastService.getWeatherForecast(
                latitude = location.latitude,
                longitude = location.longitude
            )
            val bundle = parseOpenMeteoResponse(location, response)

            // Update cached summary in Room for the Locations list
            val currentPoint = bundle.hourlyPoints.getOrNull(bundle.currentHourIndex)
            if (currentPoint != null) {
                val updatedEntity = location.copy(
                    timezone = bundle.timezoneId,
                    lastTempC = currentPoint.tempC,
                    lastWeatherCode = currentPoint.weatherCode,
                    lastWindKmh = currentPoint.windSpeedKmh,
                    lastHumidity = currentPoint.humidity,
                    lastIsDay = currentPoint.isDay,
                    lastUpdatedMillis = System.currentTimeMillis()
                )
                weatherDao.updateLocation(updatedEntity)
                val finalBundle = bundle.copy(location = updatedEntity)
                bundleMemoryCache[location.id] = finalBundle
                return@withContext finalBundle
            }

            bundleMemoryCache[location.id] = bundle
            bundle
        } catch (_: Exception) {
            // If network is unreachable, return cached memory bundle or build resilient physics fallback
            cached ?: buildResilientFallbackBundle(location)
        }
    }

    fun evaluateTimeWatchRules(
        rules: List<TimeWatchRuleEntity>,
        activeBundle: LocationWeatherBundle?
    ): List<TimeWatchEvaluation> {
        return rules.map { rule ->
            val bundleForRule = bundleMemoryCache[rule.locationId]
                ?: if (activeBundle?.location?.id == rule.locationId) activeBundle else null

            val targetHourFormatted = "${WeatherFormatter.formatHourLabel24(rule.targetHour)} (${WeatherFormatter.formatHourLabel12(rule.targetHour)})"

            if (bundleForRule == null) {
                TimeWatchEvaluation(
                    rule = rule,
                    targetHourFormatted = targetHourFormatted,
                    matchedPoint = null,
                    isTriggered = false,
                    triggerReasons = emptyList(),
                    statusSummary = "Select ${rule.locationName} to sync live hourly forecast"
                )
            } else {
                // Find the next upcoming occurrence of targetHour starting from currentHourIndex
                val upcomingMatch = bundleForRule.hourlyPoints
                    .drop(bundleForRule.currentHourIndex)
                    .firstOrNull { it.hourOfDay == rule.targetHour }
                    ?: bundleForRule.hourlyPoints.firstOrNull { it.hourOfDay == rule.targetHour }

                if (upcomingMatch == null) {
                    TimeWatchEvaluation(
                        rule = rule,
                        targetHourFormatted = targetHourFormatted,
                        matchedPoint = null,
                        isTriggered = false,
                        triggerReasons = emptyList(),
                        statusSummary = "Hourly window unavailable"
                    )
                } else {
                    val reasons = mutableListOf<String>()
                    if (upcomingMatch.precipProb >= rule.maxRainProbPercent) {
                        reasons.add("Rain probability ${upcomingMatch.precipProb}% (threshold ${rule.maxRainProbPercent}%)")
                    }
                    if (upcomingMatch.windSpeedKmh >= rule.maxWindKmh) {
                        reasons.add(String.format(Locale.US, "Wind %.0f km/h (max %.0f km/h)", upcomingMatch.windSpeedKmh, rule.maxWindKmh))
                    }
                    if (upcomingMatch.tempC < rule.minTempC) {
                        reasons.add(String.format(Locale.US, "Low temp %.0f°C (min %.0f°C)", upcomingMatch.tempC, rule.minTempC))
                    }
                    if (upcomingMatch.tempC > rule.maxTempC) {
                        reasons.add(String.format(Locale.US, "High temp %.0f°C (max %.0f°C)", upcomingMatch.tempC, rule.maxTempC))
                    }

                    val wmo = WeatherFormatter.resolveWmoCode(upcomingMatch.weatherCode, upcomingMatch.isDay)
                    val summary = if (reasons.isEmpty()) {
                        "Optimal conditions: ${wmo.title}, ${upcomingMatch.tempC.roundToInt()}°C, Rain ${upcomingMatch.precipProb}%"
                    } else {
                        "Advisory at ${upcomingMatch.displayDayLabel} ${upcomingMatch.displayTime24h}: ${reasons.joinToString(" • ")}"
                    }

                    TimeWatchEvaluation(
                        rule = rule,
                        targetHourFormatted = targetHourFormatted,
                        matchedPoint = upcomingMatch,
                        isTriggered = reasons.isNotEmpty() && rule.isEnabled,
                        triggerReasons = reasons,
                        statusSummary = summary
                    )
                }
            }
        }
    }

    private fun parseOpenMeteoResponse(
        location: MonitoredLocationEntity,
        response: OpenMeteoForecastResponse
    ): LocationWeatherBundle {
        val tzId = response.timezone ?: location.timezone.ifBlank { "UTC" }
        val timeZone = TimeZone.getTimeZone(tzId)
        val nowCal = Calendar.getInstance(timeZone)

        val currentYear = nowCal.get(Calendar.YEAR)
        val currentMonth = nowCal.get(Calendar.MONTH) + 1
        val currentDay = nowCal.get(Calendar.DAY_OF_MONTH)
        val currentHour = nowCal.get(Calendar.HOUR_OF_DAY)

        val todayKey = String.format(Locale.US, "%04d-%02d-%02d", currentYear, currentMonth, currentDay)

        val tomorrowCal = (nowCal.clone() as Calendar).apply { add(Calendar.DAY_OF_YEAR, 1) }
        val tomorrowKey = String.format(
            Locale.US,
            "%04d-%02d-%02d",
            tomorrowCal.get(Calendar.YEAR),
            tomorrowCal.get(Calendar.MONTH) + 1,
            tomorrowCal.get(Calendar.DAY_OF_MONTH)
        )

        val yesterdayCal = (nowCal.clone() as Calendar).apply { add(Calendar.DAY_OF_YEAR, -1) }
        val yesterdayKey = String.format(
            Locale.US,
            "%04d-%02d-%02d",
            yesterdayCal.get(Calendar.YEAR),
            yesterdayCal.get(Calendar.MONTH) + 1,
            yesterdayCal.get(Calendar.DAY_OF_MONTH)
        )

        val timeFormat12 = SimpleDateFormat("h:mm a", Locale.US).apply { this.timeZone = timeZone }
        val dateFormatFull = SimpleDateFormat("EEE, MMM d", Locale.US).apply { this.timeZone = timeZone }
        val isoDayParser = SimpleDateFormat("yyyy-MM-dd", Locale.US).apply { this.timeZone = timeZone }

        val currentLocalTimeFormatted = timeFormat12.format(nowCal.time)
        val currentLocalDateFormatted = dateFormatFull.format(nowCal.time)

        val hourlyDto = response.hourly
        val times = hourlyDto?.time.orEmpty()

        // Find the index corresponding to the location's current hour
        val targetCurrentIsoPrefix = String.format(Locale.US, "%sT%02d:", todayKey, currentHour)
        var matchedCurrentIdx = times.indexOfFirst { it.startsWith(targetCurrentIsoPrefix) }
        if (matchedCurrentIdx < 0) {
            matchedCurrentIdx = (times.size / 3).coerceAtLeast(0)
        }

        val hourlyPoints = times.mapIndexed { idx, iso ->
            val dayPart = iso.substringBefore("T", todayKey)
            val hourPart = iso.substringAfter("T", "00:00").substringBefore(":").toIntOrNull() ?: 0

            val dayLabel = when (dayPart) {
                todayKey -> "Today"
                tomorrowKey -> "Tomorrow"
                yesterdayKey -> "Yesterday"
                else -> {
                    val parsedDate = runCatching { isoDayParser.parse(dayPart) }.getOrNull()
                    if (parsedDate != null) dateFormatFull.format(parsedDate) else dayPart
                }
            }

            val rawVisibilityMeters = hourlyDto?.visibility?.getOrNull(idx) ?: 10000.0
            val visibilityKm = (rawVisibilityMeters / 1000.0).coerceIn(0.2, 50.0)

            HourlyWeatherPoint(
                index = idx,
                isoTime = iso,
                dayKey = dayPart,
                hourOfDay = hourPart,
                displayTime12h = WeatherFormatter.formatHourLabel12(hourPart),
                displayTime24h = WeatherFormatter.formatHourLabel24(hourPart),
                displayDayLabel = dayLabel,
                tempC = hourlyDto?.temperature2m?.getOrNull(idx)
                    ?: response.current?.temperature2m
                    ?: 20.0,
                feelsLikeC = hourlyDto?.apparentTemperature?.getOrNull(idx)
                    ?: response.current?.apparentTemperature
                    ?: 20.0,
                humidity = (hourlyDto?.relativeHumidity2m?.getOrNull(idx)
                    ?: response.current?.relativeHumidity2m
                    ?: 60).coerceIn(0, 100),
                dewPointC = hourlyDto?.dewPoint2m?.getOrNull(idx) ?: 12.0,
                precipProb = (hourlyDto?.precipitationProbability?.getOrNull(idx) ?: 0).coerceIn(0, 100),
                precipMm = hourlyDto?.precipitation?.getOrNull(idx) ?: 0.0,
                weatherCode = hourlyDto?.weatherCode?.getOrNull(idx)
                    ?: response.current?.weatherCode
                    ?: 0,
                pressureHpa = hourlyDto?.surfacePressure?.getOrNull(idx)
                    ?: response.current?.surfacePressure
                    ?: 1013.2,
                cloudCover = (hourlyDto?.cloudCover?.getOrNull(idx)
                    ?: response.current?.cloudCover
                    ?: 20).coerceIn(0, 100),
                visibilityKm = visibilityKm,
                windSpeedKmh = hourlyDto?.windSpeed10m?.getOrNull(idx)
                    ?: response.current?.windSpeed10m
                    ?: 10.0,
                windDirectionDeg = hourlyDto?.windDirection10m?.getOrNull(idx)
                    ?: response.current?.windDirection10m
                    ?: 180,
                windGustsKmh = hourlyDto?.windGusts10m?.getOrNull(idx)
                    ?: response.current?.windGusts10m
                    ?: 15.0,
                uvIndex = (hourlyDto?.uvIndex?.getOrNull(idx) ?: 0.0).coerceAtLeast(0.0),
                isDay = (hourlyDto?.isDay?.getOrNull(idx) ?: if (hourPart in 6..18) 1 else 0) == 1,
                isCurrentHour = idx == matchedCurrentIdx,
                hoursOffsetFromNow = idx - matchedCurrentIdx
            )
        }

        val dailyDto = response.daily
        val dailyDates = dailyDto?.time.orEmpty()
        val dayOfWeekFormatter = SimpleDateFormat("EEEE", Locale.US).apply { this.timeZone = timeZone }
        val shortDateFormatter = SimpleDateFormat("MMM d", Locale.US).apply { this.timeZone = timeZone }

        val dailySummaries = dailyDates.mapIndexed { idx, dateIso ->
            val parsedDate: Date? = runCatching { isoDayParser.parse(dateIso) }.getOrNull()
            val displayDayName = when (dateIso) {
                todayKey -> "Today"
                tomorrowKey -> "Tomorrow"
                yesterdayKey -> "Yesterday"
                else -> if (parsedDate != null) dayOfWeekFormatter.format(parsedDate) else dateIso
            }
            val displayShortDate = if (parsedDate != null) shortDateFormatter.format(parsedDate) else dateIso

            val sunriseIso = dailyDto?.sunrise?.getOrNull(idx) ?: "${dateIso}T06:15"
            val sunsetIso = dailyDto?.sunset?.getOrNull(idx) ?: "${dateIso}T18:30"

            val sunriseTimePart = sunriseIso.substringAfter("T", "06:15")
            val sunsetTimePart = sunsetIso.substringAfter("T", "18:30")

            val sunriseHourFloat = parseHourFloat(sunriseTimePart, 6.25f)
            val sunsetHourFloat = parseHourFloat(sunsetTimePart, 18.5f)

            val firstHourIdx = hourlyPoints.indexOfFirst { it.dayKey == dateIso && it.hourOfDay == 12 }
                .takeIf { it >= 0 }
                ?: hourlyPoints.indexOfFirst { it.dayKey == dateIso }.coerceAtLeast(0)

            DailyWeatherSummary(
                dateIso = dateIso,
                displayDayName = displayDayName,
                displayShortDate = displayShortDate,
                weatherCode = dailyDto?.weatherCode?.getOrNull(idx) ?: 1,
                maxTempC = dailyDto?.temperature2mMax?.getOrNull(idx) ?: 24.0,
                minTempC = dailyDto?.temperature2mMin?.getOrNull(idx) ?: 14.0,
                sunriseIso = sunriseIso,
                sunsetIso = sunsetIso,
                sunriseFormatted = sunriseTimePart,
                sunsetFormatted = sunsetTimePart,
                sunriseHourFloat = sunriseHourFloat,
                sunsetHourFloat = sunsetHourFloat,
                uvMax = dailyDto?.uvIndexMax?.getOrNull(idx) ?: 6.0,
                precipProbMax = dailyDto?.precipitationProbabilityMax?.getOrNull(idx) ?: 10,
                precipSumMm = dailyDto?.precipitationSum?.getOrNull(idx) ?: 0.0,
                maxWindKmh = dailyDto?.windSpeed10mMax?.getOrNull(idx) ?: 16.0,
                firstHourIndex = firstHourIdx
            )
        }

        return LocationWeatherBundle(
            location = location,
            timezoneId = tzId,
            timezoneAbbrev = response.timezoneAbbreviation ?: timeZone.getDisplayName(false, TimeZone.SHORT, Locale.US),
            utcOffsetSeconds = response.utcOffsetSeconds ?: (timeZone.rawOffset / 1000),
            elevationMeters = response.elevation ?: 25.0,
            currentLocalTimeFormatted = currentLocalTimeFormatted,
            currentLocalDateFormatted = currentLocalDateFormatted,
            currentHourIndex = matchedCurrentIdx.coerceIn(0, (hourlyPoints.size - 1).coerceAtLeast(0)),
            hourlyPoints = hourlyPoints,
            dailySummaries = dailySummaries,
            fetchedAtMillis = System.currentTimeMillis(),
            isFromLiveNetwork = true
        )
    }

    private fun parseHourFloat(hhMm: String, fallback: Float): Float {
        val parts = hhMm.split(":")
        val h = parts.getOrNull(0)?.toIntOrNull() ?: return fallback
        val m = parts.getOrNull(1)?.toIntOrNull() ?: 0
        return h + (m / 60f)
    }

    private fun buildResilientFallbackBundle(location: MonitoredLocationEntity): LocationWeatherBundle {
        val tzId = location.timezone.ifBlank { "UTC" }
        val timeZone = TimeZone.getTimeZone(tzId)
        val baseCal = Calendar.getInstance(timeZone)
        val currentHour = baseCal.get(Calendar.HOUR_OF_DAY)

        val timeFormat12 = SimpleDateFormat("h:mm a", Locale.US).apply { this.timeZone = timeZone }
        val dateFormatFull = SimpleDateFormat("EEE, MMM d", Locale.US).apply { this.timeZone = timeZone }
        val isoFormatter = SimpleDateFormat("yyyy-MM-dd", Locale.US).apply { this.timeZone = timeZone }
        val dayNameFormatter = SimpleDateFormat("EEEE", Locale.US).apply { this.timeZone = timeZone }
        val shortDateFormatter = SimpleDateFormat("MMM d", Locale.US).apply { this.timeZone = timeZone }

        val currentLocalTimeFormatted = timeFormat12.format(baseCal.time)
        val currentLocalDateFormatted = dateFormatFull.format(baseCal.time)

        // Start 1 day in the past, generate 8 days (192 hours)
        val startDayCal = (baseCal.clone() as Calendar).apply {
            add(Calendar.DAY_OF_YEAR, -1)
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }

        val latitudeFactor = (90.0 - kotlin.math.abs(location.latitude)) / 90.0
        val baseMedianTemp = (8.0 + latitudeFactor * 18.0).coerceIn(5.0, 30.0)

        val currentHourIndex = 24 + currentHour
        val hourlyPoints = mutableListOf<HourlyWeatherPoint>()
        val dailySummaries = mutableListOf<DailyWeatherSummary>()

        for (dayOffset in -1..6) {
            val dayCal = (startDayCal.clone() as Calendar).apply {
                add(Calendar.DAY_OF_YEAR, dayOffset + 1)
            }
            val dateIso = isoFormatter.format(dayCal.time)
            val dayLabel = when (dayOffset) {
                -1 -> "Yesterday"
                0 -> "Today"
                1 -> "Tomorrow"
                else -> dateFormatFull.format(dayCal.time)
            }
            val dailyName = when (dayOffset) {
                -1 -> "Yesterday"
                0 -> "Today"
                1 -> "Tomorrow"
                else -> dayNameFormatter.format(dayCal.time)
            }

            var dayMax = -100.0
            var dayMin = 100.0
            var maxPrecipProb = 0
            var maxWind = 0.0
            val firstIdxForDay = hourlyPoints.size + 12

            for (hour in 0..23) {
                val idx = hourlyPoints.size
                val diurnalWave = sin((hour - 9) * Math.PI / 12.0)
                val synopticWave = cos((idx + location.id) * 0.08)
                val tempC = baseMedianTemp + (diurnalWave * 5.2) + (synopticWave * 2.1)
                val feelsLikeC = tempC - 0.8
                val humidity = (66 - (diurnalWave * 18).roundToInt()).coerceIn(32, 94)
                val precipProb = ((1.0 - synopticWave) * 24.0).roundToInt().coerceIn(5, 75)
                val windSpeed = (11.0 + (diurnalWave + 1.0) * 4.5).coerceAtLeast(4.0)
                val windDeg = ((210 + idx * 5) % 360)
                val isDay = hour in 6..18
                val uv = if (isDay) (sin((hour - 6) * Math.PI / 12.0) * 7.2).coerceAtLeast(0.5) else 0.0
                val weatherCode = when {
                    precipProb > 60 -> 61
                    precipProb > 40 -> 2
                    else -> if (hour in 11..16) 1 else 0
                }

                if (tempC > dayMax) dayMax = tempC
                if (tempC < dayMin) dayMin = tempC
                if (precipProb > maxPrecipProb) maxPrecipProb = precipProb
                if (windSpeed > maxWind) maxWind = windSpeed

                hourlyPoints.add(
                    HourlyWeatherPoint(
                        index = idx,
                        isoTime = String.format(Locale.US, "%sT%02d:00", dateIso, hour),
                        dayKey = dateIso,
                        hourOfDay = hour,
                        displayTime12h = WeatherFormatter.formatHourLabel12(hour),
                        displayTime24h = WeatherFormatter.formatHourLabel24(hour),
                        displayDayLabel = dayLabel,
                        tempC = tempC,
                        feelsLikeC = feelsLikeC,
                        humidity = humidity,
                        dewPointC = tempC - ((100 - humidity) / 5.0),
                        precipProb = precipProb,
                        precipMm = if (precipProb > 55) 1.2 else 0.0,
                        weatherCode = weatherCode,
                        pressureHpa = 1014.0 + synopticWave * 4.5,
                        cloudCover = (precipProb * 1.1).roundToInt().coerceIn(8, 95),
                        visibilityKm = 16.0,
                        windSpeedKmh = windSpeed,
                        windDirectionDeg = windDeg,
                        windGustsKmh = windSpeed * 1.35,
                        uvIndex = uv,
                        isDay = isDay,
                        isCurrentHour = idx == currentHourIndex,
                        hoursOffsetFromNow = idx - currentHourIndex
                    )
                )
            }

            dailySummaries.add(
                DailyWeatherSummary(
                    dateIso = dateIso,
                    displayDayName = dailyName,
                    displayShortDate = shortDateFormatter.format(dayCal.time),
                    weatherCode = if (maxPrecipProb > 55) 61 else 1,
                    maxTempC = dayMax,
                    minTempC = dayMin,
                    sunriseIso = "${dateIso}T06:24",
                    sunsetIso = "${dateIso}T18:38",
                    sunriseFormatted = "06:24",
                    sunsetFormatted = "18:38",
                    sunriseHourFloat = 6.4f,
                    sunsetHourFloat = 18.63f,
                    uvMax = 7.2,
                    precipProbMax = maxPrecipProb,
                    precipSumMm = if (maxPrecipProb > 55) 3.4 else 0.0,
                    maxWindKmh = maxWind,
                    firstHourIndex = firstIdxForDay.coerceIn(0, (hourlyPoints.size - 1).coerceAtLeast(0))
                )
            )
        }

        return LocationWeatherBundle(
            location = location,
            timezoneId = tzId,
            timezoneAbbrev = timeZone.getDisplayName(false, TimeZone.SHORT, Locale.US),
            utcOffsetSeconds = timeZone.rawOffset / 1000,
            elevationMeters = 42.0,
            currentLocalTimeFormatted = currentLocalTimeFormatted,
            currentLocalDateFormatted = currentLocalDateFormatted,
            currentHourIndex = currentHourIndex.coerceIn(0, hourlyPoints.lastIndex),
            hourlyPoints = hourlyPoints,
            dailySummaries = dailySummaries,
            fetchedAtMillis = System.currentTimeMillis(),
            isFromLiveNetwork = false
        )
    }
}
