package com.example.data.repository

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.location.Geocoder
import android.location.Location
import android.location.LocationManager
import androidx.core.content.ContextCompat
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import com.google.android.gms.tasks.CancellationTokenSource
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import java.util.Locale
import java.util.TimeZone
import kotlin.coroutines.resume

data class ResolvedGpsLocation(
    val latitude: Double,
    val longitude: Double,
    val cityName: String,
    val regionName: String,
    val countryName: String,
    val timezoneId: String
)

class LocationTracker(private val context: Context) {

    fun hasLocationPermission(): Boolean {
        val fine = ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.ACCESS_FINE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED
        val coarse = ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.ACCESS_COARSE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED
        return fine || coarse
    }

    @SuppressLint("MissingPermission")
    suspend fun fetchCurrentGpsLocation(): Result<ResolvedGpsLocation> = withContext(Dispatchers.IO) {
        if (!hasLocationPermission()) {
            return@withContext Result.failure(
                SecurityException("Location permission has not been granted.")
            )
        }

        try {
            val fusedClient = LocationServices.getFusedLocationProviderClient(context)

            // 1. Try fresh current location with a 5-second timeout
            var rawLocation: Location? = withTimeoutOrNull(5000L) {
                suspendCancellableCoroutine { cont ->
                    val tokenSource = CancellationTokenSource()
                    cont.invokeOnCancellation { tokenSource.cancel() }
                    fusedClient.getCurrentLocation(
                        Priority.PRIORITY_BALANCED_POWER_ACCURACY,
                        tokenSource.token
                    ).addOnSuccessListener { loc ->
                        if (cont.isActive) cont.resume(loc)
                    }.addOnFailureListener {
                        if (cont.isActive) cont.resume(null)
                    }
                }
            }

            // 2. Fallback to lastLocation from FusedLocationProviderClient
            if (rawLocation == null) {
                rawLocation = withTimeoutOrNull(2500L) {
                    suspendCancellableCoroutine { cont ->
                        fusedClient.lastLocation
                            .addOnSuccessListener { loc ->
                                if (cont.isActive) cont.resume(loc)
                            }
                            .addOnFailureListener {
                                if (cont.isActive) cont.resume(null)
                            }
                    }
                }
            }

            // 3. Fallback to Android LocationManager providers
            if (rawLocation == null) {
                val locationManager = context.getSystemService(Context.LOCATION_SERVICE) as? LocationManager
                val providers = locationManager?.getProviders(true).orEmpty()
                for (provider in providers) {
                    val candidate = runCatching { locationManager?.getLastKnownLocation(provider) }.getOrNull()
                    if (candidate != null) {
                        rawLocation = candidate
                        break
                    }
                }
            }

            if (rawLocation == null) {
                return@withContext Result.failure(
                    IllegalStateException("GPS signal unavailable on this device/emulator. Try setting emulator GPS coordinates or selecting a city below.")
                )
            }

            val resolved = reverseGeocode(rawLocation.latitude, rawLocation.longitude)
            Result.success(resolved)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    @Suppress("DEPRECATION")
    private fun reverseGeocode(lat: Double, lon: Double): ResolvedGpsLocation {
        var city = "GPS Station"
        var region = String.format(Locale.US, "%.3f°, %.3f°", lat, lon)
        var country = "Live Telemetry"

        try {
            if (Geocoder.isPresent()) {
                val geocoder = Geocoder(context, Locale.getDefault())
                val addresses = geocoder.getFromLocation(lat, lon, 1)
                if (!addresses.isNullOrEmpty()) {
                    val addr = addresses[0]
                    city = addr.locality
                        ?: addr.subAdminArea
                        ?: addr.featureName
                        ?: "Current GPS Sector"
                    region = addr.adminArea ?: addr.subLocality ?: region
                    country = addr.countryName ?: addr.countryCode ?: "GPS"
                }
            }
        } catch (_: Exception) {
            // Keep coordinate fallback labels if Geocoder service is unavailable
        }

        return ResolvedGpsLocation(
            latitude = lat,
            longitude = lon,
            cityName = city,
            regionName = region,
            countryName = country,
            timezoneId = TimeZone.getDefault().id
        )
    }
}
