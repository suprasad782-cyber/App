package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface WeatherDao {

    @Query("SELECT * FROM monitored_locations ORDER BY isPrimary DESC, isGpsLocation DESC, name ASC")
    fun getAllLocations(): Flow<List<MonitoredLocationEntity>>

    @Query("SELECT * FROM monitored_locations ORDER BY isPrimary DESC, isGpsLocation DESC, name ASC")
    suspend fun getAllLocationsOnce(): List<MonitoredLocationEntity>

    @Query("SELECT * FROM monitored_locations WHERE id = :id LIMIT 1")
    suspend fun getLocationById(id: Long): MonitoredLocationEntity?

    @Query("SELECT * FROM monitored_locations WHERE isGpsLocation = 1 LIMIT 1")
    suspend fun getGpsLocation(): MonitoredLocationEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLocation(location: MonitoredLocationEntity): Long

    @Update
    suspend fun updateLocation(location: MonitoredLocationEntity)

    @Query("UPDATE monitored_locations SET isPrimary = CASE WHEN id = :selectedId THEN 1 ELSE 0 END")
    suspend fun setPrimaryLocation(selectedId: Long)

    @Query("DELETE FROM monitored_locations WHERE id = :id")
    suspend fun deleteLocationById(id: Long)

    // Weather Logs (Time Snapshots)
    @Query("SELECT * FROM weather_logs ORDER BY recordedAtMillis DESC")
    fun getAllWeatherLogs(): Flow<List<WeatherLogEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertWeatherLog(log: WeatherLogEntity): Long

    @Query("DELETE FROM weather_logs WHERE id = :id")
    suspend fun deleteWeatherLogById(id: Long)

    @Query("DELETE FROM weather_logs")
    suspend fun clearAllWeatherLogs()

    // Time Watch Rules
    @Query("SELECT * FROM time_watch_rules ORDER BY targetHour ASC, id DESC")
    fun getAllTimeWatchRules(): Flow<List<TimeWatchRuleEntity>>

    @Query("SELECT * FROM time_watch_rules ORDER BY targetHour ASC")
    suspend fun getAllTimeWatchRulesOnce(): List<TimeWatchRuleEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTimeWatchRule(rule: TimeWatchRuleEntity): Long

    @Update
    suspend fun updateTimeWatchRule(rule: TimeWatchRuleEntity)

    @Query("DELETE FROM time_watch_rules WHERE id = :id")
    suspend fun deleteTimeWatchRuleById(id: Long)
}
