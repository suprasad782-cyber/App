package com.example.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddAlarm
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.WarningAmber
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.local.MonitoredLocationEntity
import com.example.data.local.TimeWatchRuleEntity
import com.example.domain.TimeWatchEvaluation
import com.example.domain.WeatherFormatter
import java.util.Locale
import kotlin.math.roundToInt

@Composable
fun TimeWatchesScreen(
    evaluations: List<TimeWatchEvaluation>,
    savedLocations: List<MonitoredLocationEntity>,
    useFahrenheit: Boolean,
    onAddWatchRule: (
        label: String,
        location: MonitoredLocationEntity,
        targetHour: Int,
        maxRainProbPercent: Int,
        maxWindKmh: Double,
        minTempC: Double,
        maxTempC: Double
    ) -> Unit,
    onToggleRule: (TimeWatchRuleEntity) -> Unit,
    onDeleteRule: (Long) -> Unit,
    modifier: Modifier = Modifier
) {
    val colorScheme = MaterialTheme.colorScheme
    var showCreateDialog by remember { mutableStateOf(false) }

    if (showCreateDialog && savedLocations.isNotEmpty()) {
        CreateTimeWatchDialog(
            savedLocations = savedLocations,
            onDismiss = { showCreateDialog = false },
            onConfirm = { label, loc, hour, rainProb, windKmh ->
                onAddWatchRule(label, loc, hour, rainProb, windKmh, 2.0, 35.0)
                showCreateDialog = false
            }
        )
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .testTag("time_watches_screen_list"),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Location + Time Watches",
                        style = MaterialTheme.typography.headlineMedium,
                        color = colorScheme.onBackground
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Automated weather threshold checks for specific daily hours at your monitored locations.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = colorScheme.onSurfaceVariant
                    )
                }
                Spacer(modifier = Modifier.width(12.dp))
                Button(
                    onClick = { showCreateDialog = true },
                    modifier = Modifier.testTag("add_time_watch_button")
                ) {
                    Icon(
                        imageVector = Icons.Filled.AddAlarm,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(stringResource(R.string.add_time_watch))
                }
            }
        }

        if (evaluations.isEmpty()) {
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 24.dp),
                    colors = CardDefaults.cardColors(containerColor = colorScheme.surface),
                    shape = MaterialTheme.shapes.large
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(28.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            imageVector = Icons.Filled.NotificationsActive,
                            contentDescription = null,
                            tint = colorScheme.primary,
                            modifier = Modifier.size(48.dp)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = stringResource(R.string.empty_watches_title),
                            style = MaterialTheme.typography.titleLarge,
                            color = colorScheme.onSurface
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = stringResource(R.string.empty_watches_subtitle),
                            style = MaterialTheme.typography.bodyMedium,
                            color = colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        } else {
            items(evaluations, key = { it.rule.id }) { eval ->
                TimeWatchEvaluationCard(
                    evaluation = eval,
                    useFahrenheit = useFahrenheit,
                    onToggle = { onToggleRule(eval.rule) },
                    onDelete = { onDeleteRule(eval.rule.id) }
                )
            }
        }
    }
}

@Composable
private fun TimeWatchEvaluationCard(
    evaluation: TimeWatchEvaluation,
    useFahrenheit: Boolean,
    onToggle: () -> Unit,
    onDelete: () -> Unit
) {
    val colorScheme = MaterialTheme.colorScheme
    val rule = evaluation.rule
    val point = evaluation.matchedPoint

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("time_watch_card_${rule.id}"),
        colors = CardDefaults.cardColors(containerColor = colorScheme.surface),
        shape = MaterialTheme.shapes.large
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Surface(
                            color = if (!rule.isEnabled) colorScheme.surfaceVariant
                            else if (evaluation.isTriggered) colorScheme.errorContainer
                            else colorScheme.tertiaryContainer,
                            shape = CircleShape
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = if (evaluation.isTriggered) Icons.Filled.WarningAmber else Icons.Filled.CheckCircle,
                                    contentDescription = null,
                                    tint = if (!rule.isEnabled) colorScheme.onSurfaceVariant
                                    else if (evaluation.isTriggered) colorScheme.error
                                    else colorScheme.tertiary,
                                    modifier = Modifier.size(14.dp)
                                )
                                Spacer(modifier = Modifier.width(5.dp))
                                Text(
                                    text = when {
                                        !rule.isEnabled -> "PAUSED"
                                        evaluation.isTriggered -> "ADVISORY TRIGGERED"
                                        else -> "CLEAR WINDOW"
                                    },
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = if (!rule.isEnabled) colorScheme.onSurfaceVariant
                                    else if (evaluation.isTriggered) colorScheme.onErrorContainer
                                    else colorScheme.onTertiaryContainer
                                )
                            }
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = rule.locationName,
                            style = MaterialTheme.typography.labelLarge,
                            color = colorScheme.primary
                        )
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = rule.label,
                        style = MaterialTheme.typography.titleLarge,
                        color = colorScheme.onSurface
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Switch(
                        checked = rule.isEnabled,
                        onCheckedChange = { onToggle() },
                        modifier = Modifier.testTag("toggle_watch_${rule.id}")
                    )
                    IconButton(
                        onClick = onDelete,
                        modifier = Modifier.testTag("delete_watch_${rule.id}")
                    ) {
                        Icon(
                            imageVector = Icons.Filled.DeleteOutline,
                            contentDescription = "Delete watch rule",
                            tint = colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Filled.Schedule,
                    contentDescription = null,
                    tint = colorScheme.secondary,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "Target Local Window: ${evaluation.targetHourFormatted}",
                    style = MaterialTheme.typography.labelMedium,
                    color = colorScheme.secondary
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            if (point != null) {
                val wmo = WeatherFormatter.resolveWmoCode(point.weatherCode, point.isDay)
                Surface(
                    color = colorScheme.surfaceVariant.copy(alpha = 0.55f),
                    shape = MaterialTheme.shapes.medium,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = wmo.icon,
                                contentDescription = wmo.title,
                                tint = wmo.accentColor,
                                modifier = Modifier.size(26.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = "${point.displayDayLabel} ${point.displayTime24h} • ${wmo.title}",
                                    style = MaterialTheme.typography.titleSmall,
                                    color = colorScheme.onSurface
                                )
                                Text(
                                    text = evaluation.statusSummary,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = colorScheme.onSurfaceVariant
                                )
                            }
                        }

                        Text(
                            text = WeatherFormatter.formatTempWithUnit(point.tempC, useFahrenheit),
                            style = MaterialTheme.typography.headlineSmall,
                            color = colorScheme.onSurface
                        )
                    }
                }
            } else {
                Text(
                    text = evaluation.statusSummary,
                    style = MaterialTheme.typography.bodySmall,
                    color = colorScheme.onSurfaceVariant
                )
            }

            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = String.format(
                    Locale.US,
                    "Thresholds: Max Rain %d%% • Max Wind %.0f km/h",
                    rule.maxRainProbPercent,
                    rule.maxWindKmh
                ),
                style = MaterialTheme.typography.labelSmall,
                color = colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
private fun CreateTimeWatchDialog(
    savedLocations: List<MonitoredLocationEntity>,
    onDismiss: () -> Unit,
    onConfirm: (
        label: String,
        location: MonitoredLocationEntity,
        targetHour: Int,
        maxRainProbPercent: Int,
        maxWindKmh: Double
    ) -> Unit
) {
    var label by remember { mutableStateOf("") }
    var selectedLocation by remember { mutableStateOf(savedLocations.first()) }
    var targetHour by remember { mutableIntStateOf(8) }
    var maxRainProb by remember { mutableFloatStateOf(35f) }
    var maxWindKmh by remember { mutableFloatStateOf(28f) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = "New Location + Time Watch",
                style = MaterialTheme.typography.titleLarge
            )
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = label,
                    onValueChange = { label = it },
                    label = { Text("Watch Name") },
                    placeholder = { Text("e.g., Morning Cycling Check") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("watch_label_input")
                )

                Text(
                    text = "Select Location:",
                    style = MaterialTheme.typography.labelLarge
                )
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(savedLocations, key = { it.id }) { loc ->
                        FilterChip(
                            selected = loc.id == selectedLocation.id,
                            onClick = { selectedLocation = loc },
                            label = { Text(loc.name) }
                        )
                    }
                }

                Text(
                    text = "Target Local Hour: ${WeatherFormatter.formatHourLabel24(targetHour)} (${WeatherFormatter.formatHourLabel12(targetHour)})",
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.primary
                )
                Slider(
                    value = targetHour.toFloat(),
                    onValueChange = { targetHour = it.roundToInt().coerceIn(0, 23) },
                    valueRange = 0f..23f,
                    steps = 22,
                    modifier = Modifier.testTag("watch_hour_slider")
                )

                Text(
                    text = "Rain Alert Threshold: ${maxRainProb.roundToInt()}%",
                    style = MaterialTheme.typography.labelMedium
                )
                Slider(
                    value = maxRainProb,
                    onValueChange = { maxRainProb = it },
                    valueRange = 10f..90f
                )

                Text(
                    text = "Wind Alert Threshold: ${maxWindKmh.roundToInt()} km/h",
                    style = MaterialTheme.typography.labelMedium
                )
                Slider(
                    value = maxWindKmh,
                    onValueChange = { maxWindKmh = it },
                    valueRange = 10f..70f
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    onConfirm(
                        label,
                        selectedLocation,
                        targetHour,
                        maxRainProb.roundToInt(),
                        maxWindKmh.toDouble()
                    )
                },
                modifier = Modifier.testTag("confirm_create_watch_button")
            ) {
                Text("Create Watch")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}
