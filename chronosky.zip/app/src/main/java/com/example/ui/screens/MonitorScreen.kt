package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowLeft
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.AccessTime
import androidx.compose.material.icons.filled.BookmarkAdd
import androidx.compose.material.icons.filled.CloudQueue
import androidx.compose.material.icons.filled.Compress
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.MyLocation
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Thermostat
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.WaterDrop
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilledTonalIconButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.local.MonitoredLocationEntity
import com.example.domain.DailyWeatherSummary
import com.example.domain.HourlyWeatherPoint
import com.example.domain.LocationWeatherBundle
import com.example.domain.WeatherFormatter
import com.example.ui.components.ChronoTelemetryChartCard
import com.example.ui.components.SolarHorizonCard
import com.example.ui.components.WindCompassCard
import com.example.ui.viewmodel.ChronoSkyUiState
import java.util.Locale

@Composable
fun MonitorScreen(
    uiState: ChronoSkyUiState,
    savedLocations: List<MonitoredLocationEntity>,
    onRequestGpsLocation: () -> Unit,
    onRefreshWeather: () -> Unit,
    onToggleUnits: () -> Unit,
    onOpenLocationPicker: () -> Unit,
    onSelectLocation: (MonitoredLocationEntity) -> Unit,
    onScrubToHourIndex: (Int) -> Unit,
    onStepHour: (Int) -> Unit,
    onResetToNow: () -> Unit,
    onJumpToDay: (DailyWeatherSummary) -> Unit,
    onLogSnapshot: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val bundle = uiState.activeBundle
    val selectedPoint = uiState.selectedPoint
    val dayPoints = uiState.selectedDayPoints
    val dailySummary = uiState.selectedDailySummary
    var showLogNoteDialog by remember { mutableStateOf(false) }
    var snapshotNoteText by remember { mutableStateOf("") }

    if (showLogNoteDialog && bundle != null && selectedPoint != null) {
        AlertDialog(
            onDismissRequest = { showLogNoteDialog = false },
            title = {
                Text(
                    text = "Log Location-Time Snapshot",
                    style = MaterialTheme.typography.titleLarge
                )
            },
            text = {
                Column {
                    Text(
                        text = "${bundle.location.name} • ${selectedPoint.displayDayLabel} ${selectedPoint.displayTime24h}",
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Temp: ${WeatherFormatter.formatTempWithUnit(selectedPoint.tempC, uiState.useFahrenheit)} | Rain: ${selectedPoint.precipProb}% | Wind: ${WeatherFormatter.formatWindSpeed(selectedPoint.windSpeedKmh, uiState.useFahrenheit)}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    OutlinedTextField(
                        value = snapshotNoteText,
                        onValueChange = { snapshotNoteText = it },
                        label = { Text("Observation Note (optional)") },
                        placeholder = { Text("e.g., Pre-commute check, frontal passage...") },
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("snapshot_note_input")
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        onLogSnapshot(snapshotNoteText)
                        snapshotNoteText = ""
                        showLogNoteDialog = false
                    },
                    modifier = Modifier.testTag("confirm_log_snapshot_button")
                ) {
                    Text("Save to History")
                }
            },
            dismissButton = {
                TextButton(onClick = { showLogNoteDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .testTag("monitor_screen_list"),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // 1. Top Location & Live Clock Telemetry Header
        item {
            TopLocationClockBar(
                bundle = bundle,
                savedLocations = savedLocations,
                liveClockText = bundle?.let { uiState.formatLiveClockForTimezone(it.timezoneId) } ?: "--:-- UTC",
                isDetectingGps = uiState.isDetectingGps,
                useFahrenheit = uiState.useFahrenheit,
                onRequestGpsLocation = onRequestGpsLocation,
                onRefreshWeather = onRefreshWeather,
                onToggleUnits = onToggleUnits,
                onOpenLocationPicker = onOpenLocationPicker,
                onSelectLocation = onSelectLocation
            )
        }

        if (uiState.isLoadingWeather && bundle == null) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(320.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        CircularProgressIndicator()
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "Synchronizing location & hourly weather telemetry…",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        } else if (bundle != null && selectedPoint != null) {
            // 2. Hero Sky Banner + Selected Time Telemetry
            item {
                HeroChronoWeatherCard(
                    bundle = bundle,
                    selectedPoint = selectedPoint,
                    dailySummary = dailySummary,
                    useFahrenheit = uiState.useFahrenheit,
                    onResetToNow = onResetToNow,
                    onOpenLogDialog = { showLogNoteDialog = true }
                )
            }

            // 3. Interactive Chrono-Scrubber Deck (Day Pills + 24h Slider + Hourly Strip)
            item {
                ChronoScrubberDeckCard(
                    bundle = bundle,
                    selectedPoint = selectedPoint,
                    dayPoints = dayPoints,
                    useFahrenheit = uiState.useFahrenheit,
                    onScrubToHourIndex = onScrubToHourIndex,
                    onStepHour = onStepHour,
                    onResetToNow = onResetToNow,
                    onJumpToDay = onJumpToDay
                )
            }

            // 4. 24-Hour Temperature & Rain Interactive Canvas Chart
            item {
                ChronoTelemetryChartCard(
                    dayPoints = dayPoints,
                    selectedPoint = selectedPoint,
                    useFahrenheit = uiState.useFahrenheit,
                    onSelectHourPoint = { pt -> onScrubToHourIndex(pt.index) }
                )
            }

            // 5. Wind Vector Compass & Solar Arc Horizon Cards
            item {
                WindCompassCard(
                    selectedPoint = selectedPoint,
                    useImperial = uiState.useFahrenheit
                )
            }

            item {
                SolarHorizonCard(
                    dailySummary = dailySummary,
                    selectedPoint = selectedPoint
                )
            }

            // 6. 4-Card Precision Atmospheric Metrics Grid
            item {
                AtmosphericMetricsGrid(
                    selectedPoint = selectedPoint,
                    elevationMeters = bundle.elevationMeters,
                    useFahrenheit = uiState.useFahrenheit
                )
            }

            // 7. 7-Day Multi-Day Forecast (Tap any day to scrub time to that day)
            item {
                SevenDayForecastCard(
                    dailySummaries = bundle.dailySummaries,
                    selectedDayKey = selectedPoint.dayKey,
                    useFahrenheit = uiState.useFahrenheit,
                    onSelectDay = onJumpToDay
                )
            }
        }
    }
}

@Composable
private fun TopLocationClockBar(
    bundle: LocationWeatherBundle?,
    savedLocations: List<MonitoredLocationEntity>,
    liveClockText: String,
    isDetectingGps: Boolean,
    useFahrenheit: Boolean,
    onRequestGpsLocation: () -> Unit,
    onRefreshWeather: () -> Unit,
    onToggleUnits: () -> Unit,
    onOpenLocationPicker: () -> Unit,
    onSelectLocation: (MonitoredLocationEntity) -> Unit
) {
    val colorScheme = MaterialTheme.colorScheme
    val locationName = bundle?.location?.name ?: "Select Location"
    val regionCountry = bundle?.location?.let { "${it.region}, ${it.country}" } ?: ""
    val isGps = bundle?.location?.isGpsLocation == true

    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Active Location Pill
            Surface(
                modifier = Modifier
                    .weight(1f)
                    .clip(MaterialTheme.shapes.large)
                    .clickable { onOpenLocationPicker() }
                    .testTag("location_selector_pill"),
                color = colorScheme.surface,
                shape = MaterialTheme.shapes.large,
                tonalElevation = 3.dp
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = if (isGps) Icons.Filled.MyLocation else Icons.Filled.LocationOn,
                        contentDescription = null,
                        tint = colorScheme.primary,
                        modifier = Modifier.size(22.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = locationName,
                                style = MaterialTheme.typography.titleMedium,
                                color = colorScheme.onSurface,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            if (isGps) {
                                Spacer(modifier = Modifier.width(6.dp))
                                Surface(
                                    color = colorScheme.tertiaryContainer,
                                    shape = CircleShape
                                ) {
                                    Text(
                                        text = "GPS",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = colorScheme.onTertiaryContainer,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                            }
                        }
                        Text(
                            text = "$regionCountry • $liveClockText",
                            style = MaterialTheme.typography.labelSmall,
                            color = colorScheme.onSurfaceVariant,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.testTag("live_location_clock")
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.width(8.dp))

            // GPS Button
            FilledTonalIconButton(
                onClick = onRequestGpsLocation,
                modifier = Modifier
                    .size(48.dp)
                    .testTag("detect_gps_button")
            ) {
                if (isDetectingGps) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(20.dp),
                        strokeWidth = 2.dp
                    )
                } else {
                    Icon(
                        imageVector = Icons.Filled.MyLocation,
                        contentDescription = stringResource(R.string.cd_detect_gps)
                    )
                }
            }

            Spacer(modifier = Modifier.width(6.dp))

            // Unit Toggle Button (°C / °F)
            FilledTonalIconButton(
                onClick = onToggleUnits,
                modifier = Modifier
                    .size(48.dp)
                    .testTag("unit_toggle_button")
            ) {
                Text(
                    text = if (useFahrenheit) "°F" else "°C",
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.Bold
                )
            }

            Spacer(modifier = Modifier.width(6.dp))

            // Refresh Button
            IconButton(
                onClick = onRefreshWeather,
                modifier = Modifier
                    .size(48.dp)
                    .testTag("refresh_weather_button")
            ) {
                Icon(
                    imageVector = Icons.Filled.Refresh,
                    contentDescription = stringResource(R.string.cd_refresh_weather),
                    tint = colorScheme.onSurfaceVariant
                )
            }
        }

        // Quick-Switch Saved Station Chips
        if (savedLocations.size > 1) {
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.testTag("quick_locations_row")
            ) {
                items(savedLocations, key = { it.id }) { loc ->
                    val isSelected = loc.id == bundle?.location?.id
                    FilterChip(
                        selected = isSelected,
                        onClick = { onSelectLocation(loc) },
                        label = {
                            val tempLabel = loc.lastTempC?.let {
                                " ${WeatherFormatter.formatTemp(it, useFahrenheit)}"
                            } ?: ""
                            Text("${loc.name}$tempLabel")
                        },
                        leadingIcon = if (loc.isGpsLocation) {
                            {
                                Icon(
                                    imageVector = Icons.Filled.MyLocation,
                                    contentDescription = null,
                                    modifier = Modifier.size(15.dp)
                                )
                            }
                        } else null,
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = colorScheme.primaryContainer,
                            selectedLabelColor = colorScheme.onPrimaryContainer
                        ),
                        modifier = Modifier.testTag("station_chip_${loc.id}")
                    )
                }
            }
        }
    }
}

@Composable
private fun HeroChronoWeatherCard(
    bundle: LocationWeatherBundle,
    selectedPoint: HourlyWeatherPoint,
    dailySummary: DailyWeatherSummary?,
    useFahrenheit: Boolean,
    onResetToNow: () -> Unit,
    onOpenLogDialog: () -> Unit
) {
    val wmo = WeatherFormatter.resolveWmoCode(selectedPoint.weatherCode, selectedPoint.isDay)
    val bannerRes = if (selectedPoint.isDay) R.drawable.img_sky_day_banner else R.drawable.img_sky_night_banner
    val offsetBadge = WeatherFormatter.formatOffsetBadge(selectedPoint.hoursOffsetFromNow)

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("hero_weather_card"),
        shape = MaterialTheme.shapes.extraLarge,
        elevation = CardDefaults.cardElevation(defaultElevation = 6.dp)
    ) {
        Box(modifier = Modifier.fillMaxWidth()) {
            // Generated Sky Banner Background
            Image(
                painter = painterResource(id = bannerRes),
                contentDescription = stringResource(R.string.cd_weather_hero_banner),
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .matchParentSize()
            )

            // Atmospheric Dark Scrim for High Contrast Readability
            Box(
                modifier = Modifier
                    .matchParentSize()
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(
                                Color(0xBF0B1120),
                                Color(0x990F172A),
                                Color(0xEB0B1120)
                            )
                        )
                    )
            )

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp)
            ) {
                // Top Row: Time Status Badge + Coordinates
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Surface(
                        color = if (selectedPoint.isCurrentHour) Color(0xFF10B981) else Color(0xFFF59E0B),
                        shape = CircleShape
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 5.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = if (selectedPoint.isCurrentHour) Icons.Filled.AccessTime else Icons.Filled.History,
                                contentDescription = null,
                                tint = Color(0xFF0B1120),
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(5.dp))
                            Text(
                                text = offsetBadge,
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF0B1120)
                            )
                        }
                    }

                    Text(
                        text = String.format(
                            Locale.US,
                            "%.3f°N, %.3f°E • %s",
                            bundle.location.latitude,
                            bundle.location.longitude,
                            bundle.timezoneAbbrev
                        ),
                        style = MaterialTheme.typography.labelSmall,
                        color = Color(0xFFE2E8F0)
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Target Inspected Date & Hour Banner
                Text(
                    text = "${selectedPoint.displayDayLabel} • ${selectedPoint.displayTime24h} (${selectedPoint.displayTime12h})",
                    style = MaterialTheme.typography.titleMedium,
                    color = Color(0xFF38BDF8),
                    modifier = Modifier.testTag("inspected_time_label")
                )

                Spacer(modifier = Modifier.height(6.dp))

                // Main Temperature + Condition Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = WeatherFormatter.formatTempWithUnit(selectedPoint.tempC, useFahrenheit),
                        style = MaterialTheme.typography.displayLarge,
                        color = Color.White,
                        modifier = Modifier.testTag("hero_temperature_text")
                    )

                    Column(horizontalAlignment = Alignment.End) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = wmo.icon,
                                contentDescription = wmo.title,
                                tint = wmo.accentColor,
                                modifier = Modifier.size(32.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = wmo.title,
                                style = MaterialTheme.typography.headlineSmall,
                                color = Color.White
                            )
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Feels like ${WeatherFormatter.formatTemp(selectedPoint.feelsLikeC, useFahrenheit)}",
                            style = MaterialTheme.typography.bodyMedium,
                            color = Color(0xFFCBD5E1)
                        )
                        if (dailySummary != null) {
                            Text(
                                text = "Day H: ${WeatherFormatter.formatTemp(dailySummary.maxTempC, useFahrenheit)}  •  L: ${WeatherFormatter.formatTemp(dailySummary.minTempC, useFahrenheit)}",
                                style = MaterialTheme.typography.labelMedium,
                                color = Color(0xFF94A3B8)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = wmo.subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = Color(0xFFCBD5E1)
                )

                Spacer(modifier = Modifier.height(16.dp))

                // Bottom Action Row inside Hero: Log Snapshot + Reset to Live Now
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    FilledTonalButton(
                        onClick = onOpenLogDialog,
                        colors = ButtonDefaults.filledTonalButtonColors(
                            containerColor = Color(0xFF1E293B).copy(alpha = 0.9f),
                            contentColor = Color(0xFF38BDF8)
                        ),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("log_snapshot_button")
                    ) {
                        Icon(
                            imageVector = Icons.Filled.BookmarkAdd,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(stringResource(R.string.log_snapshot_button))
                    }

                    AnimatedVisibility(visible = !selectedPoint.isCurrentHour) {
                        Button(
                            onClick = onResetToNow,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Color(0xFF38BDF8),
                                contentColor = Color(0xFF0B1120)
                            ),
                            modifier = Modifier.testTag("reset_now_button")
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Schedule,
                                contentDescription = null,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(stringResource(R.string.reset_to_now))
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ChronoScrubberDeckCard(
    bundle: LocationWeatherBundle,
    selectedPoint: HourlyWeatherPoint,
    dayPoints: List<HourlyWeatherPoint>,
    useFahrenheit: Boolean,
    onScrubToHourIndex: (Int) -> Unit,
    onStepHour: (Int) -> Unit,
    onResetToNow: () -> Unit,
    onJumpToDay: (DailyWeatherSummary) -> Unit
) {
    val colorScheme = MaterialTheme.colorScheme

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("chrono_scrubber_card"),
        colors = CardDefaults.cardColors(containerColor = colorScheme.surface),
        shape = MaterialTheme.shapes.large
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Filled.Schedule,
                        contentDescription = null,
                        tint = colorScheme.primary,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = stringResource(R.string.time_scrubber_title),
                        style = MaterialTheme.typography.titleMedium,
                        color = colorScheme.onSurface
                    )
                }

                // -1h / +1h Stepper Buttons
                Row(verticalAlignment = Alignment.CenterVertically) {
                    FilledTonalIconButton(
                        onClick = { onStepHour(-1) },
                        enabled = selectedPoint.index > 0,
                        modifier = Modifier
                            .size(36.dp)
                            .testTag("step_prev_hour_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.KeyboardArrowLeft,
                            contentDescription = "Previous Hour"
                        )
                    }
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = selectedPoint.displayTime24h,
                        style = MaterialTheme.typography.labelMedium,
                        color = colorScheme.primary
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    FilledTonalIconButton(
                        onClick = { onStepHour(1) },
                        enabled = selectedPoint.index < bundle.hourlyPoints.lastIndex,
                        modifier = Modifier
                            .size(36.dp)
                            .testTag("step_next_hour_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.KeyboardArrowRight,
                            contentDescription = "Next Hour"
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Day Selector Chips (Yesterday, Today, Tomorrow, + 5 days)
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                items(bundle.dailySummaries, key = { it.dateIso }) { daily ->
                    val isSelectedDay = daily.dateIso == selectedPoint.dayKey
                    FilterChip(
                        selected = isSelectedDay,
                        onClick = { onJumpToDay(daily) },
                        label = {
                            Text("${daily.displayDayName} (${daily.displayShortDate})")
                        },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = colorScheme.primary,
                            selectedLabelColor = colorScheme.onPrimary
                        ),
                        modifier = Modifier.testTag("day_chip_${daily.dateIso}")
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // 24-Hour Slider within the selected day
            if (dayPoints.isNotEmpty()) {
                val firstDayIdx = dayPoints.first().index
                val lastDayIdx = dayPoints.last().index
                Slider(
                    value = selectedPoint.index.toFloat().coerceIn(firstDayIdx.toFloat(), lastDayIdx.toFloat()),
                    onValueChange = { newVal ->
                        onScrubToHourIndex(newVal.toInt())
                    },
                    valueRange = firstDayIdx.toFloat()..lastDayIdx.toFloat().coerceAtLeast(firstDayIdx + 1f),
                    steps = (dayPoints.size - 2).coerceAtLeast(0),
                    colors = SliderDefaults.colors(
                        thumbColor = colorScheme.secondary,
                        activeTrackColor = colorScheme.primary,
                        inactiveTrackColor = colorScheme.surfaceVariant
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("time_scrubber_slider")
                )
            }

            Spacer(modifier = Modifier.height(6.dp))

            // Horizontal Hourly Strip for the selected day
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("hourly_timeline_row")
            ) {
                items(dayPoints, key = { it.isoTime }) { pt ->
                    val isSelected = pt.index == selectedPoint.index
                    val wmo = WeatherFormatter.resolveWmoCode(pt.weatherCode, pt.isDay)
                    Surface(
                        modifier = Modifier
                            .width(74.dp)
                            .clip(MaterialTheme.shapes.medium)
                            .clickable { onScrubToHourIndex(pt.index) }
                            .border(
                                width = if (isSelected) 2.dp else 1.dp,
                                color = if (isSelected) colorScheme.primary
                                else if (pt.isCurrentHour) colorScheme.tertiary
                                else colorScheme.outline.copy(alpha = 0.3f),
                                shape = MaterialTheme.shapes.medium
                            )
                            .testTag("hour_pill_${pt.hourOfDay}"),
                        color = if (isSelected) colorScheme.primaryContainer.copy(alpha = 0.7f)
                        else colorScheme.surfaceVariant.copy(alpha = 0.55f),
                        shape = MaterialTheme.shapes.medium
                    ) {
                        Column(
                            modifier = Modifier.padding(vertical = 10.dp, horizontal = 6.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Text(
                                text = if (pt.isCurrentHour) "NOW" else pt.displayTime24h,
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = if (isSelected || pt.isCurrentHour) FontWeight.Bold else FontWeight.Normal,
                                color = if (pt.isCurrentHour) colorScheme.tertiary else colorScheme.onSurface
                            )
                            Icon(
                                imageVector = wmo.icon,
                                contentDescription = wmo.title,
                                tint = wmo.accentColor,
                                modifier = Modifier.size(22.dp)
                            )
                            Text(
                                text = WeatherFormatter.formatTemp(pt.tempC, useFahrenheit),
                                style = MaterialTheme.typography.titleSmall,
                                color = colorScheme.onSurface
                            )
                            Text(
                                text = "${pt.precipProb}%",
                                style = MaterialTheme.typography.labelSmall,
                                color = if (pt.precipProb >= 40) colorScheme.primary else colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun AtmosphericMetricsGrid(
    selectedPoint: HourlyWeatherPoint,
    elevationMeters: Double,
    useFahrenheit: Boolean
) {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            TelemetryMetricTile(
                icon = Icons.Filled.WaterDrop,
                title = "Humidity & Dew",
                primaryValue = "${selectedPoint.humidity}%",
                secondaryValue = "Dew point ${WeatherFormatter.formatTempWithUnit(selectedPoint.dewPointC, useFahrenheit)}",
                progress = selectedPoint.humidity / 100f,
                modifier = Modifier.weight(1f)
            )
            TelemetryMetricTile(
                icon = Icons.Filled.Compress,
                title = "Surface Pressure",
                primaryValue = String.format(Locale.US, "%.0f hPa", selectedPoint.pressureHpa),
                secondaryValue = when {
                    selectedPoint.pressureHpa > 1018 -> "High Pressure Ridge"
                    selectedPoint.pressureHpa < 1008 -> "Low Pressure Trough"
                    else -> "Standard Barometric"
                },
                progress = ((selectedPoint.pressureHpa - 980.0) / 60.0).toFloat().coerceIn(0f, 1f),
                modifier = Modifier.weight(1f)
            )
        }
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            TelemetryMetricTile(
                icon = Icons.Filled.CloudQueue,
                title = "Rain & Cloud Deck",
                primaryValue = "${selectedPoint.precipProb}% Prob",
                secondaryValue = String.format(
                    Locale.US,
                    "%.1f mm/h • Clouds %d%%",
                    selectedPoint.precipMm,
                    selectedPoint.cloudCover
                ),
                progress = selectedPoint.precipProb / 100f,
                modifier = Modifier.weight(1f)
            )
            TelemetryMetricTile(
                icon = Icons.Filled.Visibility,
                title = "Visibility & Elev",
                primaryValue = String.format(Locale.US, "%.1f km", selectedPoint.visibilityKm),
                secondaryValue = String.format(Locale.US, "Station Elev %.0f m", elevationMeters),
                progress = (selectedPoint.visibilityKm / 25.0).toFloat().coerceIn(0f, 1f),
                modifier = Modifier.weight(1f)
            )
        }
    }
}

@Composable
private fun TelemetryMetricTile(
    icon: ImageVector,
    title: String,
    primaryValue: String,
    secondaryValue: String,
    progress: Float,
    modifier: Modifier = Modifier
) {
    val colorScheme = MaterialTheme.colorScheme
    Card(
        modifier = modifier,
        colors = CardDefaults.cardColors(containerColor = colorScheme.surface),
        shape = MaterialTheme.shapes.large
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = colorScheme.primary,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = title,
                    style = MaterialTheme.typography.labelLarge,
                    color = colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = primaryValue,
                style = MaterialTheme.typography.headlineSmall,
                color = colorScheme.onSurface
            )
            Spacer(modifier = Modifier.height(6.dp))
            LinearProgressIndicator(
                progress = { progress.coerceIn(0f, 1f) },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(5.dp)
                    .clip(CircleShape),
                color = colorScheme.primary,
                trackColor = colorScheme.surfaceVariant
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = secondaryValue,
                style = MaterialTheme.typography.bodySmall,
                color = colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
private fun SevenDayForecastCard(
    dailySummaries: List<DailyWeatherSummary>,
    selectedDayKey: String,
    useFahrenheit: Boolean,
    onSelectDay: (DailyWeatherSummary) -> Unit
) {
    val colorScheme = MaterialTheme.colorScheme
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("seven_day_forecast_card"),
        colors = CardDefaults.cardColors(containerColor = colorScheme.surface),
        shape = MaterialTheme.shapes.large
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Filled.Thermostat,
                        contentDescription = null,
                        tint = colorScheme.primary,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Multi-Day Horizon (Tap to Scrub Day)",
                        style = MaterialTheme.typography.titleMedium,
                        color = colorScheme.onSurface
                    )
                }
            }

            dailySummaries.forEach { day ->
                val isSelected = day.dateIso == selectedDayKey
                val wmo = WeatherFormatter.resolveWmoCode(day.weatherCode, isDay = true)
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(MaterialTheme.shapes.medium)
                        .clickable { onSelectDay(day) }
                        .testTag("daily_row_${day.dateIso}"),
                    color = if (isSelected) colorScheme.primaryContainer.copy(alpha = 0.5f)
                    else colorScheme.surfaceVariant.copy(alpha = 0.4f),
                    shape = MaterialTheme.shapes.medium
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.width(105.dp)) {
                            Text(
                                text = day.displayDayName,
                                style = MaterialTheme.typography.titleSmall,
                                color = colorScheme.onSurface
                            )
                            Text(
                                text = day.displayShortDate,
                                style = MaterialTheme.typography.labelSmall,
                                color = colorScheme.onSurfaceVariant
                            )
                        }

                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(
                                imageVector = wmo.icon,
                                contentDescription = wmo.title,
                                tint = wmo.accentColor,
                                modifier = Modifier.size(22.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(
                                    text = wmo.title,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = colorScheme.onSurface
                                )
                                Text(
                                    text = "Rain ${day.precipProbMax}% • UV ${day.uvMax.toInt()}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = colorScheme.onSurfaceVariant
                                )
                            }
                        }

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = WeatherFormatter.formatTemp(day.minTempC, useFahrenheit),
                                style = MaterialTheme.typography.bodyMedium,
                                color = colorScheme.onSurfaceVariant
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = WeatherFormatter.formatTemp(day.maxTempC, useFahrenheit),
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = colorScheme.onSurface
                            )
                        }
                    }
                }
            }
        }
    }
}
