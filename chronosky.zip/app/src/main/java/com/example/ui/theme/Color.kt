package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Dark Atmospheric Palette (Deep Stratosphere & Luminous Cyan/Amber)
val StratosphereNavy = Color(0xFF0B1120)
val DeepSlateSurface = Color(0xFF111C33)
val ElevatedSlateCard = Color(0xFF1A2947)
val GlassCardBorder = Color(0xFF2B4168)

val ElectricCyan = Color(0xFF38BDF8)
val ElectricCyanContainer = Color(0xFF0C4A6E)
val OnElectricCyanContainer = Color(0xFFE0F2FE)

val SolarAmber = Color(0xFFFBBF24)
val SolarAmberContainer = Color(0xFF78350F)
val OnSolarAmberContainer = Color(0xFFFEF3C7)

val TelemetryMint = Color(0xFF34D399)
val TelemetryMintContainer = Color(0xFF064E3B)
val OnTelemetryMintContainer = Color(0xFFD1FAE5)

val StormCoral = Color(0xFFFB7185)
val StormCoralContainer = Color(0xFF881337)

val AlabasterWhite = Color(0xFFF8FAFC)
val MutedSkySilver = Color(0xFF94A3B8)

// Light Atmospheric Palette (Crisp Daylight Sky)
val DaylightBackground = Color(0xFFF0F6FC)
val DaylightSurface = Color(0xFFFFFFFF)
val DaylightSurfaceVariant = Color(0xFFE2EEFA)
val CeruleanPrimary = Color(0xFF0284C7)
val CeruleanPrimaryContainer = Color(0xFFE0F2FE)
val OnCeruleanPrimaryContainer = Color(0xFF075985)
val WarmSunSecondary = Color(0xFFD97706)
val WarmSunSecondaryContainer = Color(0xFFFEF3C7)
val OnWarmSunSecondaryContainer = Color(0xFF92400E)
val DeepHorizonText = Color(0xFF0F172A)
val SlateSubtleText = Color(0xFF475569)
