package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

private val ChronoSkyDarkColorScheme = darkColorScheme(
    primary = ElectricCyan,
    onPrimary = StratosphereNavy,
    primaryContainer = ElectricCyanContainer,
    onPrimaryContainer = OnElectricCyanContainer,
    secondary = SolarAmber,
    onSecondary = StratosphereNavy,
    secondaryContainer = SolarAmberContainer,
    onSecondaryContainer = OnSolarAmberContainer,
    tertiary = TelemetryMint,
    onTertiary = StratosphereNavy,
    tertiaryContainer = TelemetryMintContainer,
    onTertiaryContainer = OnTelemetryMintContainer,
    error = StormCoral,
    errorContainer = StormCoralContainer,
    onError = StratosphereNavy,
    onErrorContainer = Color(0xFFFFE4E6),
    background = StratosphereNavy,
    onBackground = AlabasterWhite,
    surface = DeepSlateSurface,
    onSurface = AlabasterWhite,
    surfaceVariant = ElevatedSlateCard,
    onSurfaceVariant = MutedSkySilver,
    outline = GlassCardBorder
)

private val ChronoSkyLightColorScheme = lightColorScheme(
    primary = CeruleanPrimary,
    onPrimary = Color.White,
    primaryContainer = CeruleanPrimaryContainer,
    onPrimaryContainer = OnCeruleanPrimaryContainer,
    secondary = WarmSunSecondary,
    onSecondary = Color.White,
    secondaryContainer = WarmSunSecondaryContainer,
    onSecondaryContainer = OnWarmSunSecondaryContainer,
    tertiary = Color(0xFF059669),
    onTertiary = Color.White,
    tertiaryContainer = OnTelemetryMintContainer,
    onTertiaryContainer = TelemetryMintContainer,
    error = Color(0xFFE11D48),
    errorContainer = Color(0xFFFFE4E6),
    onError = Color.White,
    onErrorContainer = StormCoralContainer,
    background = DaylightBackground,
    onBackground = DeepHorizonText,
    surface = DaylightSurface,
    onSurface = DeepHorizonText,
    surfaceVariant = DaylightSurfaceVariant,
    onSurfaceVariant = SlateSubtleText,
    outline = Color(0xFFCBD5E1)
)

val ChronoSkyShapes = Shapes(
    extraSmall = RoundedCornerShape(8.dp),
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(18.dp),
    large = RoundedCornerShape(24.dp),
    extraLarge = RoundedCornerShape(32.dp)
)

@Composable
fun ChronoSkyTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit,
) {
    val colorScheme = if (darkTheme) ChronoSkyDarkColorScheme else ChronoSkyLightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        shapes = ChronoSkyShapes,
        content = content
    )
}

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit,
) {
    ChronoSkyTheme(darkTheme = darkTheme, content = content)
}
