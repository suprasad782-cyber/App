package com.example.ui.screens

import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddLocationAlt
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.MyLocation
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.local.MonitoredLocationEntity
import com.example.data.remote.GeocodingResultDto
import com.example.domain.WeatherFormatter
import com.example.ui.viewmodel.ChronoSkyUiState
import java.util.Locale

@Composable
fun LocationsScreen(
    uiState: ChronoSkyUiState,
    savedLocations: List<MonitoredLocationEntity>,
    onSearchQueryChanged: (String) -> Unit,
    onAddSearchedLocation: (GeocodingResultDto) -> Unit,
    onSelectLocation: (MonitoredLocationEntity) -> Unit,
    onDeleteLocation: (MonitoredLocationEntity) -> Unit,
    onRequestGpsLocation: () -> Unit,
    modifier: Modifier = Modifier
) {
    val colorScheme = MaterialTheme.colorScheme
    val activeLocationId = uiState.activeBundle?.location?.id

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .testTag("locations_screen_list"),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Column {
                Text(
                    text = "Global Stations & Live GPS",
                    style = MaterialTheme.typography.headlineMedium,
                    color = colorScheme.onBackground
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Monitor weather across local timezones or lock onto your device's live GPS coordinates.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = colorScheme.onSurfaceVariant
                )
            }
        }

        // 1. Live GPS Detection Card
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("locations_detect_gps_card"),
                colors = CardDefaults.cardColors(
                    containerColor = colorScheme.primaryContainer.copy(alpha = 0.65f)
                ),
                shape = MaterialTheme.shapes.large
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.weight(1f)
                    ) {
                        Surface(
                            color = colorScheme.primary,
                            shape = CircleShape,
                            modifier = Modifier.size(44.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Filled.MyLocation,
                                    contentDescription = null,
                                    tint = colorScheme.onPrimary
                                )
                            }
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = "Live Device GPS Telemetry",
                                style = MaterialTheme.typography.titleMedium,
                                color = colorScheme.onSurface
                            )
                            Text(
                                text = stringResource(R.string.gps_permission_rationale),
                                style = MaterialTheme.typography.bodySmall,
                                color = colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    Spacer(modifier = Modifier.width(10.dp))

                    Button(
                        onClick = onRequestGpsLocation,
                        enabled = !uiState.isDetectingGps,
                        modifier = Modifier.testTag("locations_gps_action_button")
                    ) {
                        if (uiState.isDetectingGps) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(18.dp),
                                strokeWidth = 2.dp,
                                color = colorScheme.onPrimary
                            )
                        } else {
                            Text(stringResource(R.string.use_gps_location))
                        }
                    }
                }
            }
        }

        // 2. Global Geocoding Search Field
        item {
            OutlinedTextField(
                value = uiState.searchQuery,
                onValueChange = onSearchQueryChanged,
                label = { Text(stringResource(R.string.search_locations_hint)) },
                leadingIcon = {
                    Icon(
                        imageVector = Icons.Filled.Search,
                        contentDescription = null
                    )
                },
                trailingIcon = {
                    if (uiState.isSearchingLocations) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(20.dp),
                            strokeWidth = 2.dp
                        )
                    } else if (uiState.searchQuery.isNotEmpty()) {
                        IconButton(
                            onClick = { onSearchQueryChanged("") },
                            modifier = Modifier.testTag("clear_search_button")
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Clear,
                                contentDescription = "Clear search query"
                            )
                        }
                    }
                },
                singleLine = true,
                shape = MaterialTheme.shapes.large,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("location_search_input")
            )
        }

        // 3. Search Results (if any)
        if (uiState.searchResults.isNotEmpty()) {
            item {
                Text(
                    text = "Geocoding Matches (${uiState.searchResults.size})",
                    style = MaterialTheme.typography.titleSmall,
                    color = colorScheme.primary
                )
            }

            items(uiState.searchResults, key = { "${it.id}_${it.latitude}_${it.longitude}" }) { dto ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(MaterialTheme.shapes.medium)
                        .clickable { onAddSearchedLocation(dto) }
                        .testTag("search_result_${dto.id}"),
                    colors = CardDefaults.cardColors(containerColor = colorScheme.surfaceVariant),
                    shape = MaterialTheme.shapes.medium
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Public,
                                contentDescription = null,
                                tint = colorScheme.primary
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = dto.name,
                                    style = MaterialTheme.typography.titleMedium,
                                    color = colorScheme.onSurface
                                )
                                Text(
                                    text = listOfNotNull(dto.admin1, dto.country).joinToString(", "),
                                    style = MaterialTheme.typography.bodySmall,
                                    color = colorScheme.onSurfaceVariant
                                )
                                Text(
                                    text = String.format(
                                        Locale.US,
                                        "%.2f°, %.2f° • TZ: %s",
                                        dto.latitude,
                                        dto.longitude,
                                        dto.timezone ?: "UTC"
                                    ),
                                    style = MaterialTheme.typography.labelSmall,
                                    color = colorScheme.primary
                                )
                            }
                        }

                        Icon(
                            imageVector = Icons.Filled.AddLocationAlt,
                            contentDescription = "Add and monitor ${dto.name}",
                            tint = colorScheme.secondary
                        )
                    }
                }
            }
        }

        // 4. Saved Monitored Stations Header
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Monitored Stations (${savedLocations.size})",
                    style = MaterialTheme.typography.titleMedium,
                    color = colorScheme.onBackground
                )
                Text(
                    text = "Tap to inspect time & weather",
                    style = MaterialTheme.typography.labelSmall,
                    color = colorScheme.onSurfaceVariant
                )
            }
        }

        // 5. Saved Stations List with Local Clock & Cached Weather
        items(savedLocations, key = { it.id }) { loc ->
            val isActive = loc.id == activeLocationId
            val localClock = uiState.formatLiveClockForTimezone(loc.timezone)
            val wmo = loc.lastWeatherCode?.let {
                WeatherFormatter.resolveWmoCode(it, loc.lastIsDay)
            }

            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(MaterialTheme.shapes.large)
                    .clickable { onSelectLocation(loc) }
                    .border(
                        width = if (isActive) 2.dp else 1.dp,
                        color = if (isActive) colorScheme.primary else colorScheme.outline.copy(alpha = 0.25f),
                        shape = MaterialTheme.shapes.large
                    )
                    .testTag("saved_location_card_${loc.id}"),
                colors = CardDefaults.cardColors(containerColor = colorScheme.surface),
                shape = MaterialTheme.shapes.large
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = if (loc.isGpsLocation) Icons.Filled.MyLocation else Icons.Filled.LocationOn,
                                contentDescription = null,
                                tint = if (isActive) colorScheme.primary else colorScheme.onSurfaceVariant,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = loc.name,
                                style = MaterialTheme.typography.titleLarge,
                                color = colorScheme.onSurface,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            if (isActive) {
                                Spacer(modifier = Modifier.width(8.dp))
                                Icon(
                                    imageVector = Icons.Filled.CheckCircle,
                                    contentDescription = "Active station",
                                    tint = colorScheme.tertiary,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "${loc.region}, ${loc.country}",
                            style = MaterialTheme.typography.bodySmall,
                            color = colorScheme.onSurfaceVariant
                        )

                        Spacer(modifier = Modifier.height(6.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Filled.Schedule,
                                contentDescription = null,
                                tint = colorScheme.secondary,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "Local Time: $localClock",
                                style = MaterialTheme.typography.labelMedium,
                                color = colorScheme.secondary
                            )
                        }

                        Text(
                            text = String.format(Locale.US, "Coords: %.3f°, %.3f°", loc.latitude, loc.longitude),
                            style = MaterialTheme.typography.labelSmall,
                            color = colorScheme.onSurfaceVariant
                        )
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        if (loc.lastTempC != null) {
                            Column(horizontalAlignment = Alignment.End) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    if (wmo != null) {
                                        Icon(
                                            imageVector = wmo.icon,
                                            contentDescription = wmo.title,
                                            tint = wmo.accentColor,
                                            modifier = Modifier.size(24.dp)
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                    }
                                    Text(
                                        text = WeatherFormatter.formatTempWithUnit(loc.lastTempC, uiState.useFahrenheit),
                                        style = MaterialTheme.typography.headlineMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = colorScheme.onSurface
                                    )
                                }
                                if (wmo != null) {
                                    Text(
                                        text = wmo.title,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }

                        if (savedLocations.size > 1) {
                            Spacer(modifier = Modifier.width(8.dp))
                            IconButton(
                                onClick = { onDeleteLocation(loc) },
                                modifier = Modifier.testTag("delete_location_${loc.id}")
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.DeleteOutline,
                                    contentDescription = "Remove ${loc.name}",
                                    tint = colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
