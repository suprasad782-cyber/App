package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Explore
import androidx.compose.material.icons.filled.NightsStay
import androidx.compose.material.icons.filled.WbSunny
import androidx.compose.material.icons.filled.WbTwilight
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.domain.DailyWeatherSummary
import com.example.domain.HourlyWeatherPoint
import com.example.domain.WeatherFormatter
import java.util.Locale
import kotlin.math.cos
import kotlin.math.roundToInt
import kotlin.math.sin

@Composable
fun ChronoTelemetryChartCard(
    dayPoints: List<HourlyWeatherPoint>,
    selectedPoint: HourlyWeatherPoint,
    useFahrenheit: Boolean,
    onSelectHourPoint: (HourlyWeatherPoint) -> Unit,
    modifier: Modifier = Modifier
) {
    val colorScheme = MaterialTheme.colorScheme
    val primaryColor = colorScheme.primary
    val secondaryColor = colorScheme.secondary
    val outlineColor = colorScheme.outline.copy(alpha = 0.35f)

    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("chrono_telemetry_chart_card"),
        colors = CardDefaults.cardColors(
            containerColor = colorScheme.surface
        ),
        shape = MaterialTheme.shapes.large
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "24-Hour Diurnal Curve (${selectedPoint.displayDayLabel})",
                        style = MaterialTheme.typography.titleMedium,
                        color = colorScheme.onSurface
                    )
                    Text(
                        text = "Tap or drag across the timeline to inspect any hour",
                        style = MaterialTheme.typography.bodySmall,
                        color = colorScheme.onSurfaceVariant
                    )
                }
                Surface(
                    color = colorScheme.primaryContainer,
                    shape = MaterialTheme.shapes.small
                ) {
                    Text(
                        text = "${selectedPoint.displayTime24h} • ${WeatherFormatter.formatTemp(selectedPoint.tempC, useFahrenheit)}",
                        style = MaterialTheme.typography.labelMedium,
                        color = colorScheme.onPrimaryContainer,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            if (dayPoints.isNotEmpty()) {
                val minTemp = (dayPoints.minOf { it.tempC } - 2.0)
                val maxTemp = (dayPoints.maxOf { it.tempC } + 2.0).coerceAtLeast(minTemp + 4.0)

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(176.dp)
                        .testTag("chrono_chart_canvas")
                        .pointerInput(dayPoints) {
                            detectTapGestures { offset ->
                                val width = size.width.toFloat().coerceAtLeast(1f)
                                val fraction = (offset.x / width).coerceIn(0f, 1f)
                                val targetIdx = (fraction * (dayPoints.size - 1)).roundToInt()
                                    .coerceIn(0, dayPoints.lastIndex)
                                onSelectHourPoint(dayPoints[targetIdx])
                            }
                        }
                        .pointerInput(dayPoints) {
                            detectHorizontalDragGestures { change, _ ->
                                change.consume()
                                val width = size.width.toFloat().coerceAtLeast(1f)
                                val fraction = (change.position.x / width).coerceIn(0f, 1f)
                                val targetIdx = (fraction * (dayPoints.size - 1)).roundToInt()
                                    .coerceIn(0, dayPoints.lastIndex)
                                onSelectHourPoint(dayPoints[targetIdx])
                            }
                        }
                ) {
                    Canvas(modifier = Modifier.fillMaxSize()) {
                        val w = size.width
                        val h = size.height
                        val topPad = 18.dp.toPx()
                        val bottomPad = 24.dp.toPx()
                        val chartHeight = (h - topPad - bottomPad).coerceAtLeast(10f)
                        val count = dayPoints.size.coerceAtLeast(2)
                        val stepX = w / (count - 1).toFloat()

                        // 1. Horizontal reference dashed lines
                        val dashEffect = PathEffect.dashPathEffect(floatArrayOf(8f, 8f), 0f)
                        for (i in 0..3) {
                            val y = topPad + (chartHeight * i / 3f)
                            drawLine(
                                color = outlineColor,
                                start = Offset(0f, y),
                                end = Offset(w, y),
                                strokeWidth = 1.dp.toPx(),
                                pathEffect = dashEffect
                            )
                        }

                        // 2. Precipitation probability bars along bottom
                        val barWidth = (stepX * 0.55f).coerceAtLeast(4f)
                        dayPoints.forEachIndexed { idx, pt ->
                            if (pt.precipProb > 0) {
                                val xCenter = idx * stepX
                                val barH = (pt.precipProb / 100f) * (chartHeight * 0.45f)
                                val isSelected = pt.hourOfDay == selectedPoint.hourOfDay
                                drawRoundRect(
                                    color = if (isSelected) primaryColor.copy(alpha = 0.55f)
                                    else primaryColor.copy(alpha = 0.22f),
                                    topLeft = Offset(xCenter - barWidth / 2f, topPad + chartHeight - barH),
                                    size = Size(barWidth, barH),
                                    cornerRadius = CornerRadius(4f, 4f)
                                )
                            }
                        }

                        // 3. Compute coordinates for smooth temperature curve
                        val points = dayPoints.mapIndexed { idx, pt ->
                            val x = idx * stepX
                            val norm = ((pt.tempC - minTemp) / (maxTemp - minTemp)).toFloat().coerceIn(0f, 1f)
                            val y = topPad + chartHeight * (1f - norm)
                            Offset(x, y)
                        }

                        val linePath = Path()
                        val fillPath = Path()
                        if (points.isNotEmpty()) {
                            linePath.moveTo(points.first().x, points.first().y)
                            fillPath.moveTo(points.first().x, topPad + chartHeight)
                            fillPath.lineTo(points.first().x, points.first().y)

                            for (i in 0 until points.size - 1) {
                                val p0 = points[i]
                                val p1 = points[i + 1]
                                val ctrlX = (p0.x + p1.x) / 2f
                                linePath.cubicTo(ctrlX, p0.y, ctrlX, p1.y, p1.x, p1.y)
                                fillPath.cubicTo(ctrlX, p0.y, ctrlX, p1.y, p1.x, p1.y)
                            }

                            fillPath.lineTo(points.last().x, topPad + chartHeight)
                            fillPath.close()

                            drawPath(
                                path = fillPath,
                                brush = Brush.verticalGradient(
                                    colors = listOf(
                                        secondaryColor.copy(alpha = 0.35f),
                                        primaryColor.copy(alpha = 0.08f),
                                        Color.Transparent
                                    ),
                                    startY = topPad,
                                    endY = topPad + chartHeight
                                )
                            )

                            drawPath(
                                path = linePath,
                                brush = Brush.horizontalGradient(
                                    colors = listOf(primaryColor, secondaryColor, primaryColor)
                                ),
                                style = Stroke(width = 3.dp.toPx(), cap = StrokeCap.Round)
                            )
                        }

                        // 4. Highlight live hour marker & selected scrubbed hour cursor
                        val selectedIdxInDay = dayPoints.indexOfFirst { it.hourOfDay == selectedPoint.hourOfDay }
                            .coerceIn(0, points.lastIndex)
                        val selOffset = points[selectedIdxInDay]

                        // Vertical cursor line
                        drawLine(
                            color = secondaryColor.copy(alpha = 0.85f),
                            start = Offset(selOffset.x, topPad * 0.4f),
                            end = Offset(selOffset.x, topPad + chartHeight),
                            strokeWidth = 2.dp.toPx(),
                            cap = StrokeCap.Round
                        )

                        // Outer glow & inner dot
                        drawCircle(
                            color = secondaryColor.copy(alpha = 0.28f),
                            radius = 11.dp.toPx(),
                            center = selOffset
                        )
                        drawCircle(
                            color = secondaryColor,
                            radius = 5.5.dp.toPx(),
                            center = selOffset
                        )
                        drawCircle(
                            color = Color.White,
                            radius = 2.5.dp.toPx(),
                            center = selOffset
                        )
                    }
                }

                // Hour axis labels + legend
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 4.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    listOf("00:00", "04:00", "08:00", "12:00", "16:00", "20:00", "23:00").forEach { label ->
                        Text(
                            text = label,
                            style = MaterialTheme.typography.labelSmall,
                            color = colorScheme.onSurfaceVariant
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(10.dp)
                                .background(secondaryColor, CircleShape)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Temp Range: ${WeatherFormatter.formatTemp(dayPoints.minOf { it.tempC }, useFahrenheit)} – ${WeatherFormatter.formatTemp(dayPoints.maxOf { it.tempC }, useFahrenheit)}",
                            style = MaterialTheme.typography.bodySmall,
                            color = colorScheme.onSurfaceVariant
                        )
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(10.dp)
                                .background(primaryColor.copy(alpha = 0.6f), CircleShape)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Rain Prob: ${selectedPoint.precipProb}%",
                            style = MaterialTheme.typography.bodySmall,
                            color = colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun SolarHorizonCard(
    dailySummary: DailyWeatherSummary?,
    selectedPoint: HourlyWeatherPoint,
    modifier: Modifier = Modifier
) {
    val colorScheme = MaterialTheme.colorScheme
    val sunriseFormatted = dailySummary?.sunriseFormatted ?: "06:20"
    val sunsetFormatted = dailySummary?.sunsetFormatted ?: "18:35"
    val sunriseH = dailySummary?.sunriseHourFloat ?: 6.33f
    val sunsetH = dailySummary?.sunsetHourFloat ?: 18.58f
    val currentH = selectedPoint.hourOfDay.toFloat()

    val isDaylight = currentH in sunriseH..sunsetH
    val daylightProgress = if (isDaylight) {
        ((currentH - sunriseH) / (sunsetH - sunriseH).coerceAtLeast(1f)).coerceIn(0f, 1f)
    } else if (currentH > sunsetH) {
        1f
    } else {
        0f
    }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("solar_horizon_card"),
        colors = CardDefaults.cardColors(containerColor = colorScheme.surface),
        shape = MaterialTheme.shapes.large
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = if (selectedPoint.isDay) Icons.Filled.WbSunny else Icons.Filled.NightsStay,
                        contentDescription = "Solar cycle status",
                        tint = if (selectedPoint.isDay) colorScheme.secondary else colorScheme.primary,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Solar Cycle & UV Telemetry",
                        style = MaterialTheme.typography.titleMedium,
                        color = colorScheme.onSurface
                    )
                }
                Surface(
                    color = if (selectedPoint.uvIndex >= 6.0) colorScheme.secondaryContainer else colorScheme.surfaceVariant,
                    shape = MaterialTheme.shapes.small
                ) {
                    Text(
                        text = String.format(Locale.US, "UV %.1f • %s", selectedPoint.uvIndex, WeatherFormatter.uvCategory(selectedPoint.uvIndex)),
                        style = MaterialTheme.typography.labelMedium,
                        color = if (selectedPoint.uvIndex >= 6.0) colorScheme.onSecondaryContainer else colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            val arcColor = colorScheme.secondary
            val nightArcColor = colorScheme.primary.copy(alpha = 0.5f)
            val horizonLineColor = colorScheme.outline.copy(alpha = 0.5f)

            Canvas(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(92.dp)
            ) {
                val w = size.width
                val h = size.height
                val horizonY = h * 0.82f
                val startX = w * 0.08f
                val endX = w * 0.92f
                val arcSpan = endX - startX
                val peakY = h * 0.14f

                // Horizon baseline
                drawLine(
                    color = horizonLineColor,
                    start = Offset(0f, horizonY),
                    end = Offset(w, horizonY),
                    strokeWidth = 1.5.dp.toPx()
                )

                // Solar parabola path
                val arcPath = Path().apply {
                    moveTo(startX, horizonY)
                    quadraticTo(w * 0.5f, peakY - (horizonY - peakY) * 0.35f, endX, horizonY)
                }
                drawPath(
                    path = arcPath,
                    color = if (isDaylight) arcColor.copy(alpha = 0.45f) else nightArcColor,
                    style = Stroke(
                        width = 2.5.dp.toPx(),
                        pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 8f), 0f)
                    )
                )

                // Position sun/moon orb along the quadratic curve for current scrubbed hour
                val t = if (isDaylight) {
                    daylightProgress
                } else {
                    (currentH / 24f).coerceIn(0f, 1f)
                }
                val ctrlX = w * 0.5f
                val ctrlY = peakY - (horizonY - peakY) * 0.35f
                val oneMinusT = 1f - t
                val orbX = oneMinusT * oneMinusT * startX + 2f * oneMinusT * t * ctrlX + t * t * endX
                val orbY = oneMinusT * oneMinusT * horizonY + 2f * oneMinusT * t * ctrlY + t * t * horizonY

                val orbColor = if (selectedPoint.isDay) arcColor else nightArcColor.copy(alpha = 0.95f)
                drawCircle(
                    color = orbColor.copy(alpha = 0.25f),
                    radius = 14.dp.toPx(),
                    center = Offset(orbX, orbY)
                )
                drawCircle(
                    color = orbColor,
                    radius = 7.dp.toPx(),
                    center = Offset(orbX, orbY)
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Filled.WbTwilight,
                        contentDescription = null,
                        tint = colorScheme.secondary,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Sunrise $sunriseFormatted",
                        style = MaterialTheme.typography.labelMedium,
                        color = colorScheme.onSurfaceVariant
                    )
                }
                Text(
                    text = "At ${selectedPoint.displayTime24h}: ${if (selectedPoint.isDay) "Daylight" else "Nighttime"}",
                    style = MaterialTheme.typography.bodySmall,
                    fontWeight = FontWeight.SemiBold,
                    color = colorScheme.onSurface
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "Sunset $sunsetFormatted",
                        style = MaterialTheme.typography.labelMedium,
                        color = colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Icon(
                        imageVector = Icons.Filled.WbTwilight,
                        contentDescription = null,
                        tint = colorScheme.primary,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun WindCompassCard(
    selectedPoint: HourlyWeatherPoint,
    useImperial: Boolean,
    modifier: Modifier = Modifier
) {
    val colorScheme = MaterialTheme.colorScheme
    val cardinal = WeatherFormatter.degreeToCardinal(selectedPoint.windDirectionDeg)

    Card(
        modifier = modifier.testTag("wind_compass_card"),
        colors = CardDefaults.cardColors(containerColor = colorScheme.surface),
        shape = MaterialTheme.shapes.large
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Filled.Explore,
                        contentDescription = "Wind vector compass",
                        tint = colorScheme.primary,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Wind Vector & Gusts",
                        style = MaterialTheme.typography.titleSmall,
                        color = colorScheme.onSurfaceVariant
                    )
                }
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = WeatherFormatter.formatWindSpeed(selectedPoint.windSpeedKmh, useImperial),
                    style = MaterialTheme.typography.headlineSmall,
                    color = colorScheme.onSurface
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Bearing: ${selectedPoint.windDirectionDeg}° ($cardinal)",
                    style = MaterialTheme.typography.labelMedium,
                    color = colorScheme.primary
                )
                Text(
                    text = "Gusts up to ${WeatherFormatter.formatWindSpeed(selectedPoint.windGustsKmh, useImperial)}",
                    style = MaterialTheme.typography.bodySmall,
                    color = colorScheme.onSurfaceVariant
                )
            }

            // Precision Compass Rose Canvas
            val dialColor = colorScheme.outline.copy(alpha = 0.5f)
            val arrowColor = colorScheme.primary
            val accentColor = colorScheme.secondary

            Box(
                modifier = Modifier.size(76.dp),
                contentAlignment = Alignment.Center
            ) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val radius = size.minDimension / 2f - 4.dp.toPx()
                    val center = Offset(size.width / 2f, size.height / 2f)

                    drawCircle(
                        color = dialColor,
                        radius = radius,
                        center = center,
                        style = Stroke(width = 2.dp.toPx())
                    )

                    // Tick marks every 45 degrees
                    for (deg in 0 until 360 step 45) {
                        val rad = Math.toRadians((deg - 90).toDouble())
                        val innerR = if (deg % 90 == 0) radius * 0.76f else radius * 0.85f
                        val start = Offset(
                            center.x + (innerR * cos(rad)).toFloat(),
                            center.y + (innerR * sin(rad)).toFloat()
                        )
                        val end = Offset(
                            center.x + (radius * cos(rad)).toFloat(),
                            center.y + (radius * sin(rad)).toFloat()
                        )
                        drawLine(
                            color = if (deg == 0) accentColor else dialColor,
                            start = start,
                            end = end,
                            strokeWidth = if (deg % 90 == 0) 2.dp.toPx() else 1.dp.toPx()
                        )
                    }

                    // Wind bearing vector needle
                    val angleRad = Math.toRadians((selectedPoint.windDirectionDeg - 90).toDouble())
                    val tip = Offset(
                        center.x + (radius * 0.68f * cos(angleRad)).toFloat(),
                        center.y + (radius * 0.68f * sin(angleRad)).toFloat()
                    )
                    val tail = Offset(
                        center.x - (radius * 0.45f * cos(angleRad)).toFloat(),
                        center.y - (radius * 0.45f * sin(angleRad)).toFloat()
                    )
                    drawLine(
                        color = arrowColor,
                        start = tail,
                        end = tip,
                        strokeWidth = 3.dp.toPx(),
                        cap = StrokeCap.Round
                    )
                    drawCircle(
                        color = accentColor,
                        radius = 4.dp.toPx(),
                        center = tip
                    )
                    drawCircle(
                        color = arrowColor,
                        radius = 3.dp.toPx(),
                        center = center
                    )
                }
                Text(
                    text = cardinal,
                    style = MaterialTheme.typography.labelSmall,
                    color = colorScheme.onSurfaceVariant,
                    modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 8.dp)
                )
            }
        }
    }
}
