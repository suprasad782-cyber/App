package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.local.MonitoredLocationEntity
import com.example.data.local.TimeWatchRuleEntity
import com.example.data.local.WeatherLogEntity
import com.example.data.remote.GeocodingResultDto
import com.example.data.repository.LocationTracker
import com.example.data.repository.WeatherRepository
import com.example.domain.DailyWeatherSummary
import com.example.domain.HourlyWeatherPoint
import com.example.domain.LocationWeatherBundle
import com.example.domain.TimeWatchEvaluation
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

enum class ChronoSkyDestination(val route: String) {
    MONITOR("monitor"),
    LOCATIONS("locations"),
    WATCHES("watches"),
    LOGS("logs")
}

data class ChronoSkyUiState(
    val currentTab: ChronoSkyDestination = ChronoSkyDestination.MONITOR,
    val isLoadingWeather: Boolean = true,
    val isDetectingGps: Boolean = false,
    val activeBundle: LocationWeatherBundle? = null,
    val selectedHourIndex: Int = 0,
    val useFahrenheit: Boolean = false,
    val searchQuery: String = "",
    val isSearchingLocations: Boolean = false,
    val searchResults: List<GeocodingResultDto> = emptyList(),
    val statusMessage: String? = null,
    val liveClockTickMillis: Long = System.currentTimeMillis()
) {
    val selectedPoint: HourlyWeatherPoint?
        get() = activeBundle?.hourlyPoints?.getOrNull(selectedHourIndex)
            ?: activeBundle?.hourlyPoints?.getOrNull(activeBundle.currentHourIndex)

    val selectedDayPoints: List<HourlyWeatherPoint>
        get() {
            val bundle = activeBundle ?: return emptyList()
            val targetDayKey = selectedPoint?.dayKey ?: return emptyList()
            return bundle.hourlyPoints.filter { it.dayKey == targetDayKey }
        }

    val selectedDailySummary: DailyWeatherSummary?
        get() {
            val bundle = activeBundle ?: return null
            val targetDayKey = selectedPoint?.dayKey ?: return bundle.dailySummaries.firstOrNull()
            return bundle.dailySummaries.firstOrNull { it.dateIso == targetDayKey }
                ?: bundle.dailySummaries.firstOrNull()
        }

    fun formatLiveClockForTimezone(timezoneId: String): String {
        val tz = TimeZone.getTimeZone(timezoneId.ifBlank { "UTC" })
        val fmt = SimpleDateFormat("HH:mm:ss z", Locale.US).apply { timeZone = tz }
        return fmt.format(Date(liveClockTickMillis))
    }
}

class WeatherViewModel(
    private val repository: WeatherRepository,
    private val locationTracker: LocationTracker
) : ViewModel() {

    private val _uiState = MutableStateFlow(ChronoSkyUiState())
    val uiState: StateFlow<ChronoSkyUiState> = _uiState.asStateFlow()

    val savedLocations: StateFlow<List<MonitoredLocationEntity>> = repository.allLocations
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val weatherLogs: StateFlow<List<WeatherLogEntity>> = repository.allWeatherLogs
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val timeWatchRules: StateFlow<List<TimeWatchRuleEntity>> = repository.allTimeWatchRules
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val timeWatchEvaluations: StateFlow<List<TimeWatchEvaluation>> = combine(
        timeWatchRules,
        _uiState
    ) { rules, state ->
        repository.evaluateTimeWatchRules(rules, state.activeBundle)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private var searchJob: Job? = null

    init {
        initializeLocationsAndWeather()
        startLiveClockTicker()
    }

    private fun startLiveClockTicker() {
        viewModelScope.launch {
            while (isActive) {
                delay(1000L)
                _uiState.update { it.copy(liveClockTickMillis = System.currentTimeMillis()) }
            }
        }
    }

    private fun initializeLocationsAndWeather() {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoadingWeather = true) }
            val locations = repository.ensureSeededLocations()
            val primary = locations.firstOrNull { it.isPrimary } ?: locations.firstOrNull()
            if (primary != null) {
                loadWeatherForLocation(primary, forceRefresh = false)
            } else {
                _uiState.update { it.copy(isLoadingWeather = false) }
            }
        }
    }

    fun selectTab(destination: ChronoSkyDestination) {
        _uiState.update { it.copy(currentTab = destination) }
    }

    fun toggleTemperatureUnit() {
        _uiState.update { it.copy(useFahrenheit = !it.useFahrenheit) }
    }

    fun clearStatusMessage() {
        _uiState.update { it.copy(statusMessage = null) }
    }

    fun scrubToHourIndex(index: Int) {
        val bundle = _uiState.value.activeBundle ?: return
        val clamped = index.coerceIn(0, (bundle.hourlyPoints.size - 1).coerceAtLeast(0))
        _uiState.update { it.copy(selectedHourIndex = clamped) }
    }

    fun stepHour(delta: Int) {
        val currentIdx = _uiState.value.selectedHourIndex
        scrubToHourIndex(currentIdx + delta)
    }

    fun resetToLiveNow() {
        val bundle = _uiState.value.activeBundle ?: return
        _uiState.update { it.copy(selectedHourIndex = bundle.currentHourIndex) }
    }

    fun jumpToDay(daily: DailyWeatherSummary) {
        val bundle = _uiState.value.activeBundle ?: return
        // If jumping to today's date, jump to currentHourIndex; otherwise jump to noon (or firstHourIndex) of that day
        val todayDayKey = bundle.hourlyPoints.getOrNull(bundle.currentHourIndex)?.dayKey
        val targetIndex = if (daily.dateIso == todayDayKey) {
            bundle.currentHourIndex
        } else {
            daily.firstHourIndex
        }
        scrubToHourIndex(targetIndex)
    }

    fun selectLocation(location: MonitoredLocationEntity, switchToMonitorTab: Boolean = true) {
        viewModelScope.launch {
            repository.selectPrimaryLocation(location.id)
            if (switchToMonitorTab) {
                _uiState.update { it.copy(currentTab = ChronoSkyDestination.MONITOR) }
            }
            loadWeatherForLocation(location, forceRefresh = false)
        }
    }

    fun refreshActiveWeather() {
        val activeLocation = _uiState.value.activeBundle?.location ?: savedLocations.value.firstOrNull() ?: return
        viewModelScope.launch {
            loadWeatherForLocation(activeLocation, forceRefresh = true)
            _uiState.update { it.copy(statusMessage = "Updated live telemetry for ${activeLocation.name}") }
        }
    }

    private suspend fun loadWeatherForLocation(
        location: MonitoredLocationEntity,
        forceRefresh: Boolean
    ) {
        _uiState.update { it.copy(isLoadingWeather = true) }
        val bundle = repository.fetchWeatherForLocation(location, forceRefresh = forceRefresh)
        _uiState.update {
            it.copy(
                isLoadingWeather = false,
                activeBundle = bundle,
                selectedHourIndex = bundle.currentHourIndex
            )
        }
    }

    fun detectAndMonitorGpsLocation() {
        viewModelScope.launch {
            _uiState.update { it.copy(isDetectingGps = true, statusMessage = null) }
            val result = locationTracker.fetchCurrentGpsLocation()
            result.onSuccess { resolved ->
                val gpsEntity = repository.upsertGpsLocation(resolved)
                val bundle = repository.fetchWeatherForLocation(gpsEntity, forceRefresh = true)
                _uiState.update {
                    it.copy(
                        isDetectingGps = false,
                        isLoadingWeather = false,
                        activeBundle = bundle,
                        selectedHourIndex = bundle.currentHourIndex,
                        currentTab = ChronoSkyDestination.MONITOR,
                        statusMessage = "GPS locked: ${resolved.cityName} (${String.format(Locale.US, "%.2f°, %.2f°", resolved.latitude, resolved.longitude)})"
                    )
                }
            }.onFailure { error ->
                _uiState.update {
                    it.copy(
                        isDetectingGps = false,
                        statusMessage = error.message ?: "Unable to acquire GPS fix."
                    )
                }
            }
        }
    }

    fun onPermissionDenied() {
        _uiState.update {
            it.copy(
                isDetectingGps = false,
                statusMessage = "Location permission denied. You can search or pick any global station."
            )
        }
    }

    fun onSearchQueryChanged(query: String) {
        _uiState.update { it.copy(searchQuery = query) }
        searchJob?.cancel()
        if (query.trim().length < 2) {
            _uiState.update { it.copy(searchResults = emptyList(), isSearchingLocations = false) }
            return
        }
        searchJob = viewModelScope.launch {
            delay(300L)
            _uiState.update { it.copy(isSearchingLocations = true) }
            val result = repository.searchLocationsRemote(query)
            result.onSuccess { list ->
                _uiState.update {
                    it.copy(
                        searchResults = list,
                        isSearchingLocations = false
                    )
                }
            }.onFailure {
                _uiState.update {
                    it.copy(
                        searchResults = emptyList(),
                        isSearchingLocations = false,
                        statusMessage = "Could not reach Geocoding service. Check connection."
                    )
                }
            }
        }
    }

    fun addSearchedLocation(dto: GeocodingResultDto) {
        viewModelScope.launch {
            _uiState.update {
                it.copy(
                    searchQuery = "",
                    searchResults = emptyList(),
                    isLoadingWeather = true,
                    currentTab = ChronoSkyDestination.MONITOR
                )
            }
            val saved = repository.addLocationFromSearch(dto, makePrimary = true)
            loadWeatherForLocation(saved, forceRefresh = true)
            _uiState.update {
                it.copy(statusMessage = "Now monitoring ${saved.name}, ${saved.country}")
            }
        }
    }

    fun deleteLocation(location: MonitoredLocationEntity) {
        viewModelScope.launch {
            val allCurrent = savedLocations.value
            if (allCurrent.size <= 1) {
                _uiState.update { it.copy(statusMessage = "Keep at least one monitored location.") }
                return@launch
            }
            val wasActive = _uiState.value.activeBundle?.location?.id == location.id
            repository.deleteLocation(location.id)
            if (wasActive) {
                val remaining = repository.ensureSeededLocations().firstOrNull { it.id != location.id }
                if (remaining != null) {
                    repository.selectPrimaryLocation(remaining.id)
                    loadWeatherForLocation(remaining, forceRefresh = false)
                }
            }
        }
    }

    fun logCurrentScrubbedSnapshot(note: String = "") {
        val bundle = _uiState.value.activeBundle ?: return
        val point = _uiState.value.selectedPoint ?: return
        viewModelScope.launch {
            repository.logWeatherSnapshot(
                location = bundle.location,
                point = point,
                note = note
            )
            _uiState.update {
                it.copy(
                    statusMessage = "Logged snapshot for ${bundle.location.name} at ${point.displayDayLabel} ${point.displayTime24h}"
                )
            }
        }
    }

    fun deleteWeatherLog(logId: Long) {
        viewModelScope.launch {
            repository.deleteWeatherLog(logId)
        }
    }

    fun clearAllWeatherLogs() {
        viewModelScope.launch {
            repository.clearAllWeatherLogs()
            _uiState.update { it.copy(statusMessage = "Cleared all logged snapshots") }
        }
    }

    fun addTimeWatchRule(
        label: String,
        location: MonitoredLocationEntity,
        targetHour: Int,
        maxRainProbPercent: Int,
        maxWindKmh: Double,
        minTempC: Double,
        maxTempC: Double
    ) {
        viewModelScope.launch {
            repository.addTimeWatchRule(
                label = label,
                location = location,
                targetHour = targetHour,
                maxRainProbPercent = maxRainProbPercent,
                maxWindKmh = maxWindKmh,
                minTempC = minTempC,
                maxTempC = maxTempC
            )
            // Also ensure weather for that location is cached so the evaluation shows immediately
            repository.fetchWeatherForLocation(location, forceRefresh = false)
            _uiState.update {
                it.copy(statusMessage = "Added time watch for ${location.name} at ${String.format(Locale.US, "%02d:00", targetHour)}")
            }
        }
    }

    fun toggleTimeWatchRule(rule: TimeWatchRuleEntity) {
        viewModelScope.launch {
            repository.toggleTimeWatchRule(rule)
        }
    }

    fun deleteTimeWatchRule(ruleId: Long) {
        viewModelScope.launch {
            repository.deleteTimeWatchRule(ruleId)
        }
    }

    class Factory(
        private val repository: WeatherRepository,
        private val locationTracker: LocationTracker
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return WeatherViewModel(repository, locationTracker) as T
        }
    }
}
