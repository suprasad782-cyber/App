package com.example

import android.Manifest
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Explore
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.WbSunny
import androidx.compose.material.icons.outlined.Explore
import androidx.compose.material.icons.outlined.History
import androidx.compose.material.icons.outlined.Notifications
import androidx.compose.material.icons.outlined.WbSunny
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.local.AppDatabase
import com.example.data.repository.LocationTracker
import com.example.data.repository.WeatherRepository
import com.example.ui.screens.HistoryLogsScreen
import com.example.ui.screens.LocationsScreen
import com.example.ui.screens.MonitorScreen
import com.example.ui.screens.TimeWatchesScreen
import com.example.ui.theme.ChronoSkyTheme
import com.example.ui.viewmodel.ChronoSkyDestination
import com.example.ui.viewmodel.WeatherViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            ChronoSkyTheme {
                ChronoSkyApp()
            }
        }
    }
}

private data class NavTabItem(
    val destination: ChronoSkyDestination,
    val labelRes: Int,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector,
    val testTag: String
)

@Composable
fun ChronoSkyApp(
    viewModel: WeatherViewModel = run {
        val context = LocalContext.current.applicationContext
        val database = remember { AppDatabase.getInstance(context) }
        val repository = remember { WeatherRepository(database.weatherDao()) }
        val locationTracker = remember { LocationTracker(context) }
        viewModel(factory = WeatherViewModel.Factory(repository, locationTracker))
    }
) {
    val context = LocalContext.current
    val locationTracker = remember { LocationTracker(context.applicationContext) }
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val savedLocations by viewModel.savedLocations.collectAsStateWithLifecycle()
    val weatherLogs by viewModel.weatherLogs.collectAsStateWithLifecycle()
    val watchEvaluations by viewModel.timeWatchEvaluations.collectAsStateWithLifecycle()

    val snackbarHostState = remember { SnackbarHostState() }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        val granted = permissions[Manifest.permission.ACCESS_FINE_LOCATION] == true ||
            permissions[Manifest.permission.ACCESS_COARSE_LOCATION] == true
        if (granted) {
            viewModel.detectAndMonitorGpsLocation()
        } else {
            viewModel.onPermissionDenied()
        }
    }

    val requestGpsAction = {
        if (locationTracker.hasLocationPermission()) {
            viewModel.detectAndMonitorGpsLocation()
        } else {
            permissionLauncher.launch(
                arrayOf(
                    Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.ACCESS_COARSE_LOCATION
                )
            )
        }
    }

    LaunchedEffect(uiState.statusMessage) {
        val msg = uiState.statusMessage
        if (!msg.isNullOrBlank()) {
            snackbarHostState.showSnackbar(msg)
            viewModel.clearStatusMessage()
        }
    }

    // Handle back button on secondary tabs to return to Monitor screen
    if (uiState.currentTab != ChronoSkyDestination.MONITOR) {
        BackHandler {
            viewModel.selectTab(ChronoSkyDestination.MONITOR)
        }
    }

    val navItems = remember {
        listOf(
            NavTabItem(
                destination = ChronoSkyDestination.MONITOR,
                labelRes = R.string.nav_monitor,
                selectedIcon = Icons.Filled.WbSunny,
                unselectedIcon = Icons.Outlined.WbSunny,
                testTag = "nav_tab_monitor"
            ),
            NavTabItem(
                destination = ChronoSkyDestination.LOCATIONS,
                labelRes = R.string.nav_locations,
                selectedIcon = Icons.Filled.Explore,
                unselectedIcon = Icons.Outlined.Explore,
                testTag = "nav_tab_locations"
            ),
            NavTabItem(
                destination = ChronoSkyDestination.WATCHES,
                labelRes = R.string.nav_watches,
                selectedIcon = Icons.Filled.NotificationsActive,
                unselectedIcon = Icons.Outlined.Notifications,
                testTag = "nav_tab_watches"
            ),
            NavTabItem(
                destination = ChronoSkyDestination.LOGS,
                labelRes = R.string.nav_logs,
                selectedIcon = Icons.Filled.History,
                unselectedIcon = Icons.Outlined.History,
                testTag = "nav_tab_logs"
            )
        )
    }

    val triggeredWatchCount = watchEvaluations.count { it.isTriggered }

    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val isWideScreen = maxWidth >= 600.dp

        Scaffold(
            modifier = Modifier.fillMaxSize(),
            contentWindowInsets = WindowInsets.safeDrawing,
            snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
            bottomBar = {
                if (!isWideScreen) {
                    NavigationBar(
                        containerColor = MaterialTheme.colorScheme.surface,
                        modifier = Modifier.testTag("bottom_navigation_bar")
                    ) {
                        navItems.forEach { item ->
                            val selected = uiState.currentTab == item.destination
                            NavigationBarItem(
                                selected = selected,
                                onClick = { viewModel.selectTab(item.destination) },
                                icon = {
                                    BadgedBox(
                                        badge = {
                                            if (item.destination == ChronoSkyDestination.WATCHES && triggeredWatchCount > 0) {
                                                Badge { Text(triggeredWatchCount.toString()) }
                                            } else if (item.destination == ChronoSkyDestination.LOGS && weatherLogs.isNotEmpty()) {
                                                Badge { Text(weatherLogs.size.toString()) }
                                            }
                                        }
                                    ) {
                                        Icon(
                                            imageVector = if (selected) item.selectedIcon else item.unselectedIcon,
                                            contentDescription = stringResource(item.labelRes)
                                        )
                                    }
                                },
                                label = { Text(stringResource(item.labelRes)) },
                                modifier = Modifier.testTag(item.testTag)
                            )
                        }
                    }
                }
            }
        ) { innerPadding ->
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                if (isWideScreen) {
                    NavigationRail(
                        containerColor = MaterialTheme.colorScheme.surface,
                        modifier = Modifier
                            .fillMaxHeight()
                            .testTag("side_navigation_rail")
                    ) {
                        navItems.forEach { item ->
                            val selected = uiState.currentTab == item.destination
                            NavigationRailItem(
                                selected = selected,
                                onClick = { viewModel.selectTab(item.destination) },
                                icon = {
                                    Icon(
                                        imageVector = if (selected) item.selectedIcon else item.unselectedIcon,
                                        contentDescription = stringResource(item.labelRes)
                                    )
                                },
                                label = { Text(stringResource(item.labelRes)) },
                                modifier = Modifier.testTag(item.testTag)
                            )
                        }
                    }
                }

                Box(modifier = Modifier.weight(1f).fillMaxHeight()) {
                    when (uiState.currentTab) {
                        ChronoSkyDestination.MONITOR -> {
                            MonitorScreen(
                                uiState = uiState,
                                savedLocations = savedLocations,
                                onRequestGpsLocation = requestGpsAction,
                                onRefreshWeather = viewModel::refreshActiveWeather,
                                onToggleUnits = viewModel::toggleTemperatureUnit,
                                onOpenLocationPicker = { viewModel.selectTab(ChronoSkyDestination.LOCATIONS) },
                                onSelectLocation = { loc -> viewModel.selectLocation(loc, switchToMonitorTab = false) },
                                onScrubToHourIndex = viewModel::scrubToHourIndex,
                                onStepHour = viewModel::stepHour,
                                onResetToNow = viewModel::resetToLiveNow,
                                onJumpToDay = viewModel::jumpToDay,
                                onLogSnapshot = viewModel::logCurrentScrubbedSnapshot
                            )
                        }

                        ChronoSkyDestination.LOCATIONS -> {
                            LocationsScreen(
                                uiState = uiState,
                                savedLocations = savedLocations,
                                onSearchQueryChanged = viewModel::onSearchQueryChanged,
                                onAddSearchedLocation = viewModel::addSearchedLocation,
                                onSelectLocation = { loc -> viewModel.selectLocation(loc, switchToMonitorTab = true) },
                                onDeleteLocation = viewModel::deleteLocation,
                                onRequestGpsLocation = requestGpsAction
                            )
                        }

                        ChronoSkyDestination.WATCHES -> {
                            TimeWatchesScreen(
                                evaluations = watchEvaluations,
                                savedLocations = savedLocations,
                                useFahrenheit = uiState.useFahrenheit,
                                onAddWatchRule = viewModel::addTimeWatchRule,
                                onToggleRule = viewModel::toggleTimeWatchRule,
                                onDeleteRule = viewModel::deleteTimeWatchRule
                            )
                        }

                        ChronoSkyDestination.LOGS -> {
                            HistoryLogsScreen(
                                logs = weatherLogs,
                                useFahrenheit = uiState.useFahrenheit,
                                onDeleteLog = viewModel::deleteWeatherLog,
                                onClearAllLogs = viewModel::clearAllWeatherLogs
                            )
                        }
                    }
                }
            }
        }
    }
}
