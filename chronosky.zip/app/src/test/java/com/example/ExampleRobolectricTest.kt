package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.domain.WeatherFormatter
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun `read app name string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("ChronoSky", appName)
    }

    @Test
    fun `weather formatter converts temperature and time offsets accurately`() {
        assertEquals("20°C", WeatherFormatter.formatTempWithUnit(20.0, useFahrenheit = false))
        assertEquals("68°F", WeatherFormatter.formatTempWithUnit(20.0, useFahrenheit = true))
        assertEquals("LIVE NOW", WeatherFormatter.formatOffsetBadge(0))
        assertEquals("+4h AHEAD", WeatherFormatter.formatOffsetBadge(4))
        assertEquals("-3h PAST", WeatherFormatter.formatOffsetBadge(-3))
        assertTrue(WeatherFormatter.resolveWmoCode(95, isDay = false).title.contains("Thunderstorm"))
    }
}
